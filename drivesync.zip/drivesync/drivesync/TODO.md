# Task: Update Storage and File Upload Limits

## Storage Limit Changes (5GB → 100GB)
- [x] Update homepage stat in `index.php` from "5GB" to "100GB"
- [x] Update CTA text in `shared-file.php` from "5GB" to "100GB"
- [ ] Update storage display and calculation in `upload.php` from "5 GB" to "100 GB"

## File Upload Limit Changes (100MB → 1GB)
- [ ] Update PHP logic in `upload.php` (comment, variable, error message)
- [ ] Update JavaScript validation in `upload.php`
- [ ] Update UI displays in `upload.php` (sidebar stats, restrictions list)
