// Drag and drop file upload
const uploadArea = document.querySelector('.upload-area');
const fileInput = document.getElementById('fileInput');

if (uploadArea) {
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        uploadArea.addEventListener(eventName, preventDefaults, false);
    });
    
    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }
    
    ['dragenter', 'dragover'].forEach(eventName => {
        uploadArea.addEventListener(eventName, highlight, false);
    });
    
    ['dragleave', 'drop'].forEach(eventName => {
        uploadArea.addEventListener(eventName, unhighlight, false);
    });
    
    function highlight() {
        uploadArea.style.borderColor = '#FFD700';
        uploadArea.style.backgroundColor = '#222222';
    }
    
    function unhighlight() {
        uploadArea.style.borderColor = '#444444';
        uploadArea.style.backgroundColor = 'transparent';
    }
    
    uploadArea.addEventListener('drop', handleDrop, false);
    
    function handleDrop(e) {
        const dt = e.dataTransfer;
        const files = dt.files;
        
        if (files.length > 0) {
            fileInput.files = files;
            fileInput.dispatchEvent(new Event('change'));
        }
    }
}

// File preview functionality
function previewFile(file) {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onloadend = function() {
        const preview = document.getElementById('preview');
        if (preview) {
            preview.innerHTML = `
                <div class="file-preview">
                    <img src="${reader.result}" alt="Preview" style="max-width: 200px;">
                    <p>${file.name}</p>
                </div>
            `;
        }
    };
}

// Share link generator
function generateShareLink(fileId) {
    const shareUrl = `${window.location.origin}/share.php?id=${fileId}`;
    navigator.clipboard.writeText(shareUrl).then(() => {
        alert('Share link copied to clipboard!');
    });
}

// Responsive menu toggle
function toggleMenu() {
    const sidebar = document.querySelector('.sidebar');
    sidebar.classList.toggle('active');
}