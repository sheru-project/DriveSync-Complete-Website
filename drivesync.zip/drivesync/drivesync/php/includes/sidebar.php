<style>
    .sidebar {
        width: 250px;
        background-color: #111111;
        color: #FFFFFF;
        padding: 1rem;
        height: 100vh;
        position: fixed;
        left: 0;
        top: 0;
        overflow-y: auto;
        border-right: 1px solid #333333;
        z-index: 1000;
    }

    .sidebar-header {
        text-align: center;
        padding-bottom: 1.5rem;
        border-bottom: 1px solid #333333;
        margin-bottom: 1.5rem;
    }

    .sidebar-logo {
        font-size: 1.5rem;
        color: #FFD700;
        font-weight: bold;
        margin-bottom: 0.5rem;
    }

    .sidebar-user {
        font-size: 0.9rem;
        color: #AAAAAA;
    }

    .sidebar-menu {
        list-style: none;
        padding: 0;
        margin: 0;
    }

    .sidebar-menu li {
        margin-bottom: 0.5rem;
    }

    .sidebar-menu a {
        display: flex;
        align-items: center;
        padding: 0.75rem 1rem;
        color: #CCCCCC;
        text-decoration: none;
        border-radius: 8px;
        transition: all 0.3s ease;
        gap: 12px;
    }

    .sidebar-menu a:hover,
    .sidebar-menu a.active {
        background-color: rgba(255, 215, 0, 0.1);
        color: #FFD700;
    }

    .sidebar-menu a i {
        width: 20px;
        text-align: center;
    }

    .sidebar-footer {
        position: absolute;
        bottom: 1rem;
        left: 1rem;
        right: 1rem;
    }

    .logout-btn {
        display: flex;
        align-items: center;
        padding: 0.75rem 1rem;
        background-color: #FF5252;
        color: #FFFFFF;
        text-decoration: none;
        border-radius: 8px;
        transition: all 0.3s ease;
        gap: 12px;
        width: 100%;
        justify-content: center;
    }

    .logout-btn:hover {
        background-color: #D32F2F;
        transform: translateY(-2px);
    }

    @media (max-width: 768px) {
        .sidebar {
            width: 100%;
            height: auto;
            position: relative;
            border-right: none;
            border-bottom: 1px solid #333333;
        }
    }
</style>

<div class="sidebar">
    <div class="sidebar-header">
        <div class="sidebar-logo">
            <i class="fas fa-cloud"></i> DriveSync
        </div>
        <div class="sidebar-user">
            Welcome, <?php echo htmlspecialchars($_SESSION['user_name'] ?? 'User'); ?>
        </div>
    </div>

    <ul class="sidebar-menu">
        <li>
            <a href="files.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'files.php' ? 'active' : ''; ?>">
                <i class="fas fa-folder"></i> My Files
            </a>
        </li>
        <li>
            <a href="upload.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'upload.php' ? 'active' : ''; ?>">
                <i class="fas fa-upload"></i> Upload
            </a>
        </li>
        <li>
            <a href="share.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'share.php' ? 'active' : ''; ?>">
                <i class="fas fa-share-alt"></i> Shared Files
            </a>
        </li>
        <li>
            <a href="profile.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'profile.php' ? 'active' : ''; ?>">
                <i class="fas fa-user"></i> Profile
            </a>
        </li>
        <li>
            <a href="change-password.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'change-password.php' ? 'active' : ''; ?>">
                <i class="fas fa-key"></i> Change Password
            </a>
        </li>
    </ul>

    <div class="sidebar-footer">
        <a href="../auth/logout.php" class="logout-btn">
            <i class="fas fa-sign-out-alt"></i> Logout
        </a>
    </div>
</div>
