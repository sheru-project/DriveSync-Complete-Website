<?php
session_start();
require_once '../config/database.php';

// Check if user came from signup
if (!isset($_SESSION['temp_email'])) {
    header("Location: signup.php");
    exit();
}

$email = $_SESSION['temp_email'];
$stored_otp = $_SESSION['temp_otp'] ?? '';

// Check if OTP is expired (10 minutes)
if (isset($_SESSION['otp_time']) && (time() - $_SESSION['otp_time']) > 600) {
    unset($_SESSION['temp_otp']);
    unset($_SESSION['otp_time']);
    $_SESSION['error'] = "OTP expired! Please request a new one.";
    header("Location: resend-otp.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $entered_otp = $_POST['otp'];
    
    if ($entered_otp == $stored_otp) {
        // OTP verified - activate user account
        $sql = "UPDATE users SET is_verified = 1, otp_code = NULL, otp_expiry = NULL WHERE email = '$email'";
        
        if (mysqli_query($conn, $sql)) {
            // Get user data
            $user_sql = "SELECT * FROM users WHERE email = '$email'";
            $user_result = mysqli_query($conn, $user_sql);
            $user = mysqli_fetch_assoc($user_result);
            
            // Set session for auto login
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_name'] = $user['first_name'] . ' ' . $user['last_name'];
            
            // Clear temp session data
            unset($_SESSION['temp_email']);
            unset($_SESSION['temp_otp']);
            unset($_SESSION['otp_time']);
            
            $_SESSION['message'] = "Email verified successfully!";
            header("Location: ../dashboard/files.php");
            exit();
        } else {
            $error = "Database error!";
        }
    } else {
        $error = "Invalid OTP code!";
    }
}

$message = $_SESSION['message'] ?? '';
$error = $_SESSION['error'] ?? '';
unset($_SESSION['message']);
unset($_SESSION['error']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify OTP - DriveSync</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: #000;
            color: #fff;
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            padding: 20px;
        }
        .container {
            background: #111;
            padding: 40px;
            border-radius: 10px;
            border: 1px solid #333;
            max-width: 400px;
            width: 100%;
            text-align: center;
        }
        h2 {
            color: #FFD700;
            margin-bottom: 20px;
        }
        .otp-display {
            background: #222;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
            border: 2px solid #FFD700;
        }
        .otp-display code {
            font-size: 32px;
            color: #FFD700;
            font-weight: bold;
            letter-spacing: 10px;
            font-family: monospace;
        }
        .otp-input {
            width: 100%;
            padding: 15px;
            background: #222;
            border: 1px solid #333;
            border-radius: 5px;
            color: #fff;
            font-size: 24px;
            text-align: center;
            letter-spacing: 15px;
            font-family: monospace;
            margin: 20px 0;
        }
        button {
            width: 100%;
            padding: 15px;
            background: linear-gradient(45deg, #FFD700, #FFA500);
            border: none;
            border-radius: 5px;
            color: #000;
            font-weight: bold;
            cursor: pointer;
            font-size: 16px;
        }
        .alert {
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .alert-success {
            background: rgba(76, 175, 80, 0.1);
            color: #4CAF50;
            border-left: 4px solid #4CAF50;
        }
        .alert-error {
            background: rgba(255, 82, 82, 0.1);
            color: #ff5252;
            border-left: 4px solid #ff5252;
        }
        .links {
            margin-top: 20px;
        }
        .links a {
            color: #FFD700;
            text-decoration: none;
            margin: 0 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2><i class="fas fa-shield-alt"></i> Verify OTP</h2>
        
        <?php if ($message): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?php echo $message; ?>
            </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
            </div>
        <?php endif; ?>
        
        <p>Enter the OTP sent to:<br>
        <strong><?php echo htmlspecialchars($email); ?></strong></p>
        
        <?php if ($stored_otp): ?>
            <div class="otp-display">
                <p>For testing, your OTP is:</p>
                <code><?php echo $stored_otp; ?></code>
                <p style="color: #888; font-size: 12px; margin-top: 10px;">
                    (Copy and paste this)
                </p>
            </div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <input type="text" 
                   name="otp" 
                   class="otp-input"
                   maxlength="6" 
                   placeholder="000000" 
                   required 
                   pattern="[0-9]{6}"
                   autofocus>
            
            <button type="submit">
                <i class="fas fa-check"></i> Verify & Login
            </button>
        </form>
        
        <div class="links">
            <a href="resend-otp.php"><i class="fas fa-redo"></i> Resend OTP</a>
            <a href="login.php"><i class="fas fa-sign-in-alt"></i> Back to Login</a>
        </div>
    </div>

    <script>
        const otpInput = document.querySelector('.otp-input');
        
        otpInput.addEventListener('input', function() {
            this.value = this.value.replace(/[^0-9]/g, '');
            if (this.value.length === 6) {
                this.form.submit();
            }
        });
        
        // Auto-hide alerts
        setTimeout(() => {
            document.querySelectorAll('.alert').forEach(alert => {
                alert.style.opacity = '0';
                setTimeout(() => alert.remove(), 300);
            });
        }, 5000);
    </script>
</body>
</html>