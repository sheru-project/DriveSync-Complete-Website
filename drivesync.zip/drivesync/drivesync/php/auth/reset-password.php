<?php
require_once '../config/database.php';

$error = '';
$success = '';
$token_valid = false;

if (isset($_GET['token'])) {
    $token = mysqli_real_escape_string($conn, $_GET['token']);
    
    $sql = "SELECT * FROM users WHERE reset_token = '$token' 
            AND reset_expiry > NOW()";
    $result = mysqli_query($conn, $sql);
    
    if (mysqli_num_rows($result) == 1) {
        $user = mysqli_fetch_assoc($result);
        $token_valid = true;
        $user_id = $user['id'];
    } else {
        $error = "Invalid or expired reset token!";
    }
} else {
    $error = "No reset token provided!";
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && $token_valid) {
    $new_password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    if ($new_password === $confirm_password) {
        if (strlen($new_password) >= 6) {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            
            $update_sql = "UPDATE users SET 
                          password = '$hashed_password',
                          reset_token = NULL,
                          reset_expiry = NULL
                          WHERE id = '$user_id'";
            
            if (mysqli_query($conn, $update_sql)) {
                $success = "Password reset successfully!";
                $token_valid = false;
            }
        } else {
            $error = "Password must be at least 6 characters!";
        }
    } else {
        $error = "Passwords do not match!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reset Password - DriveSync</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>
    <div class="auth-container">
        <h2 class="form-title"><i class="fas fa-key" style="color: #FFD700;"></i> Reset Password</h2>
        
        <?php if ($error): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
            </div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                <p style="margin-top: 10px;">
                    <a href="login.php" class="btn-primary">Login Now</a>
                </p>
            </div>
        <?php elseif ($token_valid): ?>
            <form method="POST" action="">
                <div class="form-group">
                    <label>New Password</label>
                    <input type="password" name="password" class="form-control" required 
                           placeholder="Enter new password">
                </div>
                
                <div class="form-group">
                    <label>Confirm Password</label>
                    <input type="password" name="confirm_password" class="form-control" required 
                           placeholder="Confirm new password">
                </div>
                
                <button type="submit" class="btn-primary" style="width: 100%;">
                    <i class="fas fa-save"></i> Reset Password
                </button>
            </form>
        <?php else: ?>
            <div class="alert alert-info">
                <i class="fas fa-info-circle"></i> 
                Please use the reset link sent to your email.
            </div>
            <div style="text-align: center; margin-top: 1rem;">
                <a href="login.php" style="color: #FFD700;">
                    <i class="fas fa-arrow-left"></i> Back to Login
                </a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>