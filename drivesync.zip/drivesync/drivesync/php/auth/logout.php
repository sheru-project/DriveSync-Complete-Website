<?php
session_start();

// Destroy all session data
session_unset();
session_destroy();

// Delete cookies if any
setcookie('remember_token', '', time() - 3600, '/');

// Redirect to home page
header("Location: ../../index.php");
exit();
?>