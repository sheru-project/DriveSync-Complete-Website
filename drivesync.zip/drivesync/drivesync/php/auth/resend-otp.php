<?php
// resend-otp.php
session_start();
require_once '../config/database.php';
require_once '../config/email.php';

$email = $_GET['email'] ?? $_SESSION['temp_email'] ?? '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    
    // Check if email exists and not verified
    $sql = "SELECT * FROM users WHERE email = '$email' AND is_verified = 0";
    $result = mysqli_query($conn, $sql);
    
    if (mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);
        
        // Generate new OTP
        $new_otp = rand(100000, 999999);
        $otp_expiry = date('Y-m-d H:i:s', strtotime('+10 minutes'));
        
        // Update OTP in database
        $update_sql = "UPDATE users SET otp_code = '$new_otp', otp_expiry = '$otp_expiry' WHERE email = '$email'";
        
        if (mysqli_query($conn, $update_sql)) {
            // Send OTP email
            $emailSender = new EmailSender();
            $emailSender->sendOTP($email, $user['first_name'] . ' ' . $user['last_name'], $new_otp);
            
            // Store in session
            $_SESSION['temp_email'] = $email;
            $_SESSION['temp_otp'] = $new_otp;
            
            $_SESSION['message'] = "New OTP sent to your email!";
            header("Location: verify-otp.php");
            exit();
        }
    } else {
        $error = "Email not found or already verified!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Resend OTP - DriveSync</title>
    <style>
        body { background: #000; color: #fff; font-family: Arial; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; padding: 20px; }
        .container { background: #111; padding: 40px; border-radius: 10px; border: 1px solid #333; max-width: 400px; width: 100%; }
        h2 { color: #FFD700; text-align: center; margin-bottom: 20px; }
        input { width: 100%; padding: 12px; margin: 10px 0; background: #222; border: 1px solid #333; border-radius: 5px; color: #fff; }
        button { width: 100%; padding: 12px; background: linear-gradient(45deg, #FFD700, #FFA500); border: none; border-radius: 5px; color: #000; font-weight: bold; cursor: pointer; }
        .error { color: #ff5252; text-align: center; }
        .success { color: #4CAF50; text-align: center; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Resend OTP</h2>
        
        <?php if (isset($_SESSION['message'])): ?>
            <div class="success"><?php echo $_SESSION['message']; unset($_SESSION['message']); ?></div>
        <?php endif; ?>
        
        <?php if (isset($error)): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <p style="text-align: center; color: #888; margin-bottom: 20px;">
                Enter your email to resend OTP
            </p>
            
            <input type="email" name="email" placeholder="Enter your email" value="<?php echo htmlspecialchars($email); ?>" required>
            
            
        </form>
        
        <p style="text-align: center; margin-top: 20px;">
            <a href="login.php" style="color: #FFD700;">Back to Login</a>
        </p>
    </div>
</body>
</html>