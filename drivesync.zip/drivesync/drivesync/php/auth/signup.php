<?php
require_once '../config/session.php';
require_once '../config/database.php';

// Include email configuration
require_once '../config/email.php'; 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $first_name = mysqli_real_escape_string($conn, $_POST['first_name']);
    $middle_name = mysqli_real_escape_string($conn, $_POST['middle_name'] ?? '');
    $last_name = mysqli_real_escape_string($conn, $_POST['last_name']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    
    // Check if email already exists
    $check_sql = "SELECT id FROM users WHERE email = '$email'";
    $check_result = mysqli_query($conn, $check_sql);
    
    if (mysqli_num_rows($check_result) > 0) {
        $_SESSION['error'] = "Email already registered!";
        header("Location: signup.php");
        exit();
    }
    
    // Hash password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
    // Generate OTP
    $otp = rand(100000, 999999);
    $otp_expiry = date('Y-m-d H:i:s', strtotime('+10 minutes'));
    
    // Save user with OTP (not verified yet)
    $sql = "INSERT INTO users (email, password, first_name, middle_name, last_name, phone, otp_code, otp_expiry) 
            VALUES ('$email', '$hashed_password', '$first_name', '$middle_name', '$last_name', '$phone', '$otp', '$otp_expiry')";
    
    if (mysqli_query($conn, $sql)) {
        $user_id = mysqli_insert_id($conn);
        
        // Create EmailSender instance
        $emailSender = new EmailSender();
        
        // Send OTP email
        $toName = $first_name . ' ' . $last_name;
        $emailSent = $emailSender->sendOTP($email, $toName, $otp);
        
        if ($emailSent) {
            // Store data in session for OTP verification
            $_SESSION['temp_user_id'] = $user_id;
            $_SESSION['temp_email'] = $email;
            $_SESSION['temp_first_name'] = $first_name;
            $_SESSION['temp_last_name'] = $last_name;
            
            $_SESSION['message'] = "Registration successful! Check your email for OTP.";
            
            // Redirect to OTP verification page
            header("Location: verify-otp.php?email=" . urlencode($email));
            exit();
        } else {
            // If email failed, still allow verification but show warning
            $_SESSION['temp_user_id'] = $user_id;
            $_SESSION['temp_email'] = $email;
            $_SESSION['otp'] = $otp; // Store OTP in session for manual entry
            $_SESSION['warning'] = "Registration successful but email delivery failed. Your OTP is: " . $otp;
            
            header("Location: verify-otp.php?email=" . urlencode($email));
            exit();
        }
    } else {
        $_SESSION['error'] = "Registration failed: " . mysqli_error($conn);
        header("Location: signup.php");
        exit();
    }
}

// Check for messages
$message = isset($_SESSION['message']) ? $_SESSION['message'] : '';
$error = isset($_SESSION['error']) ? $_SESSION['error'] : '';

// Clear messages
unset($_SESSION['message']);
unset($_SESSION['error']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - DriveSync</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #000000;
            color: #FFFFFF;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            background: linear-gradient(135deg, #0A0A0A 0%, #000000 100%);
        }

        .auth-container {
            width: 100%;
            max-width: 500px;
            background: linear-gradient(135deg, #111111, #0A0A0A);
            padding: 2.5rem;
            border-radius: 15px;
            border: 1px solid #222222;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.5);
        }

        .form-title {
            color: #FFD700;
            text-align: center;
            margin-bottom: 2rem;
            font-size: 2rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 15px;
        }

        .form-title i {
            font-size: 1.8rem;
        }

        /* Alerts */
        .alert {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 2rem;
            border-left: 4px solid;
            display: flex;
            align-items: center;
            gap: 12px;
            animation: slideIn 0.3s ease;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .alert-success {
            background-color: rgba(76, 175, 80, 0.1);
            border-color: #4CAF50;
            color: #A5D6A7;
        }

        .alert-error {
            background-color: rgba(255, 82, 82, 0.1);
            border-color: #FF5252;
            color: #FF8A80;
        }

        .alert-warning {
            background-color: rgba(255, 193, 7, 0.1);
            border-color: #FFC107;
            color: #FFECB3;
        }

        /* Form Styles */
        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #CCCCCC;
            font-weight: 500;
            font-size: 0.95rem;
        }

        .form-control {
            width: 100%;
            padding: 14px 15px;
            background-color: #111111;
            border: 1px solid #333333;
            border-radius: 8px;
            color: #FFFFFF;
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        .form-control:focus {
            outline: none;
            border-color: #FFD700;
            box-shadow: 0 0 0 2px rgba(255, 215, 0, 0.1);
        }

        .form-control::placeholder {
            color: #666666;
        }

        /* Password input group */
        .password-input-group {
            position: relative;
        }

        .password-toggle {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: #888888;
            cursor: pointer;
            font-size: 1rem;
            transition: color 0.3s ease;
        }

        .password-toggle:hover {
            color: #FFD700;
        }

        /* Buttons */
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 14px 24px;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.3s ease;
            width: 100%;
            justify-content: center;
        }

        .btn-primary {
            background: linear-gradient(135deg, #FFD700 0%, #FFA500 100%);
            color: #000000;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(255, 215, 0, 0.4);
        }

        .btn-primary:active {
            transform: translateY(0);
        }

        /* Password Requirements */
        .password-requirements {
            background-color: #0A0A0A;
            border: 1px solid #333333;
            border-radius: 8px;
            padding: 1rem;
            margin-top: 0.5rem;
            margin-bottom: 1.5rem;
        }

        .password-requirements h4 {
            color: #FFD700;
            margin-bottom: 0.8rem;
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .requirement-list {
            list-style: none;
        }

        .requirement-list li {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 6px;
            color: #888888;
            font-size: 0.85rem;
        }

        .requirement-list li i {
            font-size: 0.8rem;
            width: 16px;
        }

        .requirement-list li.valid {
            color: #4CAF50;
        }

        .requirement-list li.invalid {
            color: #FF5252;
        }

        /* Links */
        .auth-links {
            text-align: center;
            margin-top: 1.5rem;
            padding-top: 1.5rem;
            border-top: 1px solid #333333;
        }

        .auth-links p {
            color: #888888;
            margin-bottom: 10px;
        }

        .auth-links a {
            color: #FFD700;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s ease;
        }

        .auth-links a:hover {
            color: #FFA500;
            text-decoration: underline;
        }

        /* Password Strength */
        .password-strength {
            margin-top: 5px;
            height: 4px;
            background-color: #333333;
            border-radius: 2px;
            overflow: hidden;
        }

        .strength-bar {
            height: 100%;
            width: 0;
            border-radius: 2px;
            transition: all 0.3s ease;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .auth-container {
                padding: 2rem;
            }
            
            .form-title {
                font-size: 1.8rem;
            }
        }

        @media (max-width: 480px) {
            .auth-container {
                padding: 1.5rem;
            }
            
            body {
                padding: 15px;
            }
        }
    </style>
</head>
<body>
    <div class="auth-container">
        <h2 class="form-title">
            <i class="fas fa-cloud"></i> Create Account
        </h2>
        
        <?php if ($message): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <span><?php echo htmlspecialchars($message); ?></span>
            </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i>
                <span><?php echo htmlspecialchars($error); ?></span>
            </div>
        <?php endif; ?>
        
        <form method="POST" action="" id="signupForm">
            <!-- Email -->
            <div class="form-group">
                <label for="email">
                    <i class="fas fa-envelope"></i> Email Address
                </label>
                <input type="email" id="email" name="email" 
                       class="form-control" 
                       placeholder="Enter your email address" 
                       required
                       onblur="checkEmailAvailability(this.value)">
                <small id="emailAvailability" style="color: #888; font-size: 0.85rem; margin-top: 5px; display: block;"></small>
            </div>
            
            <!-- Password -->
            <div class="form-group">
                <label for="password">
                    <i class="fas fa-lock"></i> Password
                </label>
                <div class="password-input-group">
                    <input type="password" id="password" name="password" 
                           class="form-control" 
                           placeholder="Create a strong password" 
                           required
                           oninput="validatePassword()">
                    <button type="button" class="password-toggle" onclick="togglePassword('password')">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>
                <div class="password-strength">
                    <div class="strength-bar" id="strengthBar"></div>
                </div>
                
                <!-- Password Requirements -->
                <div class="password-requirements">
                    <h4><i class="fas fa-info-circle"></i> Password Requirements:</h4>
                    <ul class="requirement-list" id="requirementList">
                        <li id="req-length" class="invalid">
                            <i class="fas fa-times"></i> At least 8 characters
                        </li>
                        <li id="req-uppercase" class="invalid">
                            <i class="fas fa-times"></i> One uppercase letter
                        </li>
                        <li id="req-lowercase" class="invalid">
                            <i class="fas fa-times"></i> One lowercase letter
                        </li>
                        <li id="req-number" class="invalid">
                            <i class="fas fa-times"></i> One number
                        </li>
                        <li id="req-special" class="invalid">
                            <i class="fas fa-times"></i> One special character
                        </li>
                    </ul>
                </div>
            </div>
            
            <!-- Confirm Password -->
            <div class="form-group">
                <label for="confirm_password">
                    <i class="fas fa-lock"></i> Confirm Password
                </label>
                <div class="password-input-group">
                    <input type="password" id="confirm_password" name="confirm_password" 
                           class="form-control" 
                           placeholder="Confirm your password" 
                           required
                           oninput="validatePasswordMatch()">
                    <button type="button" class="password-toggle" onclick="togglePassword('confirm_password')">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>
                <small id="passwordMatch" style="color: #888; font-size: 0.85rem; margin-top: 5px; display: block;"></small>
            </div>
            
            <!-- First Name -->
            <div class="form-group">
                <label for="first_name">
                    <i class="fas fa-user"></i> First Name
                </label>
                <input type="text" id="first_name" name="first_name" 
                       class="form-control" 
                       placeholder="Enter your first name" 
                       required>
            </div>
            
            <!-- Middle Name -->
            <div class="form-group">
                <label for="middle_name">
                    <i class="fas fa-user"></i> Middle Name (Optional)
                </label>
                <input type="text" id="middle_name" name="middle_name" 
                       class="form-control" 
                       placeholder="Enter your middle name">
            </div>
            
            <!-- Last Name -->
            <div class="form-group">
                <label for="last_name">
                    <i class="fas fa-user"></i> Last Name
                </label>
                <input type="text" id="last_name" name="last_name" 
                       class="form-control" 
                       placeholder="Enter your last name" 
                       required>
            </div>
            
            <!-- Phone -->
            <div class="form-group">
                <label for="phone">
                    <i class="fas fa-phone"></i> Phone Number
                </label>
                <input type="tel" id="phone" name="phone" 
                       class="form-control" 
                       placeholder="Enter your phone number" 
                       required
                       pattern="[0-9]{10,15}"
                       title="Enter valid phone number (10-15 digits)">
                <small style="color: #888; font-size: 0.85rem; margin-top: 5px; display: block;">
                    Format: 10-15 digits
                </small>
            </div>
            
            <!-- Terms and Conditions -->
            <div class="form-group" style="margin-bottom: 2rem;">
                <div style="display: flex; align-items: flex-start; gap: 10px;">
                </div>
            </div>
            
            <!-- Submit Button -->
            <button type="submit" class="btn btn-primary" id="submitBtn">
                <i class="fas fa-user-plus"></i> Create Account
            </button>
        </form>
        
        <!-- Links -->
        <div class="auth-links">
            <p>
                Already have an account? 
                <a href="login.php">
                    <i class="fas fa-sign-in-alt"></i> Login here
                </a>
            </p>
            
        </div>
    </div>

    <script>
        // Toggle password visibility
        function togglePassword(fieldId) {
            const field = document.getElementById(fieldId);
            const button = field.parentElement.querySelector('.password-toggle i');
            
            if (field.type === 'password') {
                field.type = 'text';
                button.classList.remove('fa-eye');
                button.classList.add('fa-eye-slash');
            } else {
                field.type = 'password';
                button.classList.remove('fa-eye-slash');
                button.classList.add('fa-eye');
            }
        }

        // Check email availability
        function checkEmailAvailability(email) {
            const availabilityEl = document.getElementById('emailAvailability');
            
            if (!email || email.length < 3) {
                availabilityEl.textContent = '';
                return;
            }
            
            // Show loading
            availabilityEl.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Checking availability...';
            availabilityEl.style.color = '#FFD700';
            
            // Simple email validation
            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailPattern.test(email)) {
                availabilityEl.innerHTML = '<i class="fas fa-times"></i> Invalid email format';
                availabilityEl.style.color = '#FF5252';
                return;
            }
            
            // AJAX request would go here in a real application
            // For now, we'll simulate it
            setTimeout(() => {
                // In real app, you would make an AJAX call to check database
                availabilityEl.innerHTML = '<i class="fas fa-check"></i> Email format is valid';
                availabilityEl.style.color = '#4CAF50';
            }, 500);
        }

        // Password validation
        function validatePassword() {
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            
            // Requirements
            const requirements = {
                length: password.length >= 8,
                uppercase: /[A-Z]/.test(password),
                lowercase: /[a-z]/.test(password),
                number: /[0-9]/.test(password),
                special: /[^A-Za-z0-9]/.test(password)
            };
            
            // Update requirement list
            for (const [key, isValid] of Object.entries(requirements)) {
                const element = document.getElementById('req-' + key);
                const icon = element.querySelector('i');
                
                if (isValid) {
                    element.classList.remove('invalid');
                    element.classList.add('valid');
                    icon.className = 'fas fa-check';
                } else {
                    element.classList.remove('valid');
                    element.classList.add('invalid');
                    icon.className = 'fas fa-times';
                }
            }
            
            // Update password strength
            let strength = 0;
            if (requirements.length) strength++;
            if (requirements.uppercase) strength++;
            if (requirements.lowercase) strength++;
            if (requirements.number) strength++;
            if (requirements.special) strength++;
            
            const strengthBar = document.getElementById('strengthBar');
            strengthBar.className = 'strength-bar';
            
            if (strength <= 2) {
                strengthBar.classList.add('strength-weak');
                strengthBar.style.width = '33%';
                strengthBar.style.backgroundColor = '#FF5252';
            } else if (strength <= 4) {
                strengthBar.classList.add('strength-medium');
                strengthBar.style.width = '66%';
                strengthBar.style.backgroundColor = '#FFA500';
            } else {
                strengthBar.classList.add('strength-strong');
                strengthBar.style.width = '100%';
                strengthBar.style.backgroundColor = '#4CAF50';
            }
            
            // Check password match if confirm password is filled
            if (confirmPassword) {
                validatePasswordMatch();
            }
            
            // Enable/disable submit button
            updateSubmitButton();
        }

        // Check password match
        function validatePasswordMatch() {
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            const matchEl = document.getElementById('passwordMatch');
            
            if (!confirmPassword) {
                matchEl.textContent = '';
                return;
            }
            
            if (password === confirmPassword) {
                matchEl.innerHTML = '<i class="fas fa-check"></i> Passwords match';
                matchEl.style.color = '#4CAF50';
            } else {
                matchEl.innerHTML = '<i class="fas fa-times"></i> Passwords do not match';
                matchEl.style.color = '#FF5252';
            }
            
            updateSubmitButton();
        }

        // Update submit button state
        function updateSubmitButton() {
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            const terms = document.getElementById('terms').checked;
            const submitBtn = document.getElementById('submitBtn');
            
            // Check all requirements
            const requirements = {
                length: password.length >= 8,
                uppercase: /[A-Z]/.test(password),
                lowercase: /[a-z]/.test(password),
                number: /[0-9]/.test(password),
                special: /[^A-Za-z0-9]/.test(password),
                match: password === confirmPassword
            };
            
            const allValid = Object.values(requirements).every(v => v) && terms;
            
            submitBtn.disabled = !allValid;
        }

        // Form validation on submit
        document.getElementById('signupForm').addEventListener('submit', function(event) {
            const email = document.getElementById('email').value.trim();
            const password = document.getElementById('password').value.trim();
            const confirmPassword = document.getElementById('confirm_password').value.trim();
            const firstName = document.getElementById('first_name').value.trim();
            const lastName = document.getElementById('last_name').value.trim();
            const phone = document.getElementById('phone').value.trim();
            const terms = document.getElementById('terms').checked;
            
            // Basic validation
            if (!email || !password || !confirmPassword || !firstName || !lastName || !phone) {
                event.preventDefault();
                alert('Please fill in all required fields.');
                return false;
            }
            
            if (!terms) {
                event.preventDefault();
                alert('You must agree to the Terms of Service and Privacy Policy.');
                return false;
            }
            
            // Email validation
            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailPattern.test(email)) {
                event.preventDefault();
                alert('Please enter a valid email address.');
                return false;
            }
            
            // Phone validation
            const phonePattern = /^[0-9]{10,15}$/;
            if (!phonePattern.test(phone)) {
                event.preventDefault();
                alert('Please enter a valid phone number (10-15 digits).');
                return false;
            }
            
            // Password validation
            if (password !== confirmPassword) {
                event.preventDefault();
                alert('Passwords do not match.');
                return false;
            }
            
            if (password.length < 8) {
                event.preventDefault();
                alert('Password must be at least 8 characters long.');
                return false;
            }
            
            // Show loading state
            const submitBtn = document.getElementById('submitBtn');
            const originalText = submitBtn.innerHTML;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Creating Account...';
            submitBtn.disabled = true;
            
            // Allow form submission
            return true;
        });

        // Initialize on page load
        document.addEventListener('DOMContentLoaded', function() {
            // Add event listeners for real-time validation
            document.getElementById('terms').addEventListener('change', updateSubmitButton);
            
            // Auto-hide alerts after 5 seconds
            setTimeout(function() {
                const alerts = document.querySelectorAll('.alert');
                alerts.forEach(alert => {
                    alert.style.opacity = '0';
                    alert.style.transform = 'translateY(-10px)';
                    setTimeout(() => alert.remove(), 300);
                });
            }, 5000);
        });
    </script>
</body>
</html>