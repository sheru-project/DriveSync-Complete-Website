<?php
require_once '../config/database.php';

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    
    $sql = "SELECT * FROM users WHERE email = '$email'";
    $result = mysqli_query($conn, $sql);
    
    if (mysqli_num_rows($result) == 1) {
        $user = mysqli_fetch_assoc($result);
        
        // Generate reset token
        $reset_token = bin2hex(random_bytes(32));
        $expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));
        
        // Save token to database
        $update_sql = "UPDATE users SET reset_token = '$reset_token', 
                       reset_expiry = '$expiry' WHERE id = '{$user['id']}'";
        
        if (mysqli_query($conn, $update_sql)) {
            // Create reset link
            $reset_link = "http://localhost/drivesync/php/auth/reset-password.php?token=$reset_token";
            
            // In production, send email here
            // mail($email, "Password Reset", "Click here: $reset_link");
            
            // For demo, show the link
            $message = "Password reset link generated!<br><br>
                       <strong>Demo Link:</strong><br>
                       <input type='text' value='$reset_link' readonly style='width:100%; padding:5px; background:#222; color:#FFD700; border:1px solid #444;'>
                       <br><br>In production, this will be sent to your email.";
        }
    } else {
        $error = "Email not found in our system!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Forgot Password - DriveSync</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>
    <div class="auth-container">
        <h2 class="form-title"><i class="fas fa-unlock-alt" style="color: #FFD700;"></i> Forgot Password</h2>
        
        <?php if ($message): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?php echo $message; ?>
            </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
            </div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="form-group">
                <label>Enter your email address</label>
                <input type="email" name="email" class="form-control" required 
                       placeholder="registered@email.com">
            </div>
            
            <button type="submit" class="btn-primary" style="width: 100%;">
                <i class="fas fa-paper-plane"></i> Send Reset Link
            </button>
        </form>
        
        <div style="text-align: center; margin-top: 1rem;">
            <a href="login.php" style="color: #FFD700;">
                <i class="fas fa-arrow-left"></i> Back to Login
            </a>
        </div>
    </div>
</body>
</html>