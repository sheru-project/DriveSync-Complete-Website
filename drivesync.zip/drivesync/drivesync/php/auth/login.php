<?php
require_once '../config/session.php'; // ✅ YEH ADD KAREN
require_once '../config/database.php'; // ✅ YEH PEHLE SE HAI

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];
    
    $sql = "SELECT * FROM users WHERE email = '$email' AND is_verified = 1";
    $result = mysqli_query($conn, $sql);
    
    if (mysqli_num_rows($result) == 1) {
        $user = mysqli_fetch_assoc($result);
        
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_name'] = $user['first_name'] . ' ' . $user['last_name'];
            
            header("Location: ../../php/dashboard/files.php");
            exit();
        } else {
            $error = "Invalid email or password!";
        }
    } else {
        $error = "Account not found or not verified!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - DriveSync</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <nav class="navbar">
        <div class="nav-container">
            <div class="logo">
                <i class="fas fa-cloud" style="color: #FFD700;"></i>
                <span class="logo-text" style="color: #FFD700;">DriveSync</span>
            </div>
        </div>
    </nav>
    
    <div class="auth-container">
        <h2 class="form-title"><i class="fas fa-sign-in-alt" style="color: #FFD700;"></i> Login to DriveSync</h2>
        
        <?php if ($error): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
            </div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="form-group">
                <label><i class="fas fa-envelope"></i> Email Address</label>
                <input type="email" name="email" class="form-control" required 
                       placeholder="Enter your email">
            </div>
            
            <div class="form-group">
                <label><i class="fas fa-lock"></i> Password</label>
                <input type="password" name="password" class="form-control" required 
                       placeholder="Enter your password">
            </div>
            
            <div class="form-group">
                <label>
                    <input type="checkbox" name="remember"> Remember me
                </label>
            </div>
            
            <button type="submit" class="btn-primary" style="width: 100%;">
                <i class="fas fa-sign-in-alt"></i> Login
            </button>
        </form>

        <br>
        <hr>
        <br>
        
        <div class="auth-links">
            
            <p>
                Don't have an account? 
                <a href="signup.php" style="color: #FFD700;">
                    <i class="fas fa-user-plus"></i> Sign Up
                </a>
            </p>
            
        </div>
    </div>
</body>
</html>