<?php
// config/email-simple.php - Complete working auth system without email

class EmailSender {
    
    public function sendOTP($toEmail, $toName, $otp) {
        // Store OTP in session
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        $_SESSION['temp_email'] = $toEmail;
        $_SESSION['temp_otp'] = $otp;
        $_SESSION['otp_time'] = time();
        
        // Log OTP to file for debugging
        $this->logToFile($toEmail, $otp, 'OTP');
        
        return true;
    }
    
    public function sendPasswordReset($toEmail, $toName, $resetLink) {
        // Store reset link in session
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        $_SESSION['reset_email'] = $toEmail;
        $_SESSION['reset_link'] = $resetLink;
        $_SESSION['reset_time'] = time();
        
        // Log to file
        $this->logToFile($toEmail, $resetLink, 'RESET');
        
        return true;
    }
    
    private function logToFile($email, $data, $type) {
        $log_file = __DIR__ . '/../../auth_log.txt';
        $log_entry = date('Y-m-d H:i:s') . " | Type: $type | Email: $email | Data: $data\n";
        file_put_contents($log_file, $log_entry, FILE_APPEND);
    }
    
    // For testing - display OTP on screen
    public function displayOTP($otp, $email) {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        $_SESSION['show_otp'] = true;
        $_SESSION['display_otp'] = $otp;
        $_SESSION['display_email'] = $email;
        
        return true;
    }
}

// Create global instance
$emailSender = new EmailSender();
?>