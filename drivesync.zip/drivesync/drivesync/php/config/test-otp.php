<?php
// test-otp.php
session_start();
echo "<h2>Debug Information</h2>";
echo "Email: " . ($_SESSION['debug_email'] ?? 'Not set') . "<br>";
echo "OTP: " . ($_SESSION['debug_otp'] ?? 'Not set') . "<br>";
echo "Temp OTP: " . ($_SESSION['temp_otp'] ?? 'Not set') . "<br>";
?>