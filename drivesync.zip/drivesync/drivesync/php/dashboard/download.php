<?php
session_start();
require_once '../config/database.php';
require_once '../config/session.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

if (isset($_GET['id'])) {
    $file_id = mysqli_real_escape_string($conn, $_GET['id']);
    $user_id = $_SESSION['user_id'];
    
    $sql = "SELECT * FROM files WHERE id = '$file_id' AND user_id = '$user_id'";
    $result = mysqli_query($conn, $sql);
    
    if (mysqli_num_rows($result) == 1) {
        $file = mysqli_fetch_assoc($result);
        $filepath = $file['filepath'];
        $filename = $file['filename'];
        
        if (file_exists($filepath)) {
            // Update download count if you have a column
            
            // Set headers for download
            header('Content-Description: File Transfer');
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="' . basename($filename) . '"');
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            header('Content-Length: ' . filesize($filepath));
            readfile($filepath);
            exit;
        } else {
            $_SESSION['error'] = "File not found on server!";
            header("Location: files.php");
            exit();
        }
    }
}

header("Location: files.php");
exit();
?>