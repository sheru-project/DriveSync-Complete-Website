<?php
// Start session
require_once '../config/session.php';
require_once '../config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// File upload handling
$upload_message = '';
$upload_error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['file'])) {
    $file = $_FILES['file'];
    
    // Check for errors
    if ($file['error'] === UPLOAD_ERR_OK) {
        $filename = mysqli_real_escape_string($conn, basename($file['name']));
        $filetype = $file['type'];
        $filesize = $file['size'];
        
        // Check file size (max 1GB)
        $max_size = 1024 * 1024 * 1024; // 1GB
        if ($filesize > $max_size) {
            $upload_error = "File size exceeds 1GB limit!";
        } else {
            // Generate unique filename
            $file_ext = pathinfo($filename, PATHINFO_EXTENSION);
            $new_filename = time() . '_' . uniqid() . '.' . $file_ext;
            $upload_path = '../../uploads/' . $new_filename;
            
            // Create uploads directory if it doesn't exist
            if (!is_dir('../../uploads/')) {
                mkdir('../../uploads/', 0777, true);
            }
            
            // Generate share link
            $share_link = bin2hex(random_bytes(16));
            
            // Move uploaded file
            if (move_uploaded_file($file['tmp_name'], $upload_path)) {
                // Save to database
                $sql = "INSERT INTO files (user_id, filename, filepath, filetype, filesize, share_link) 
                        VALUES ('$user_id', '$filename', '$upload_path', '$filetype', '$filesize', '$share_link')";
                
                if (mysqli_query($conn, $sql)) {
                    $upload_message = "File '$filename' uploaded successfully!";
                    
                    // Redirect to files page after 2 seconds
                    header("refresh:2;url=files.php");
                } else {
                    $upload_error = "Database error: " . mysqli_error($conn);
                    // Delete uploaded file if database insert failed
                    if (file_exists($upload_path)) {
                        unlink($upload_path);
                    }
                }
            } else {
                $upload_error = "Failed to move uploaded file!";
            }
        }
    } else {
        $upload_error = "File upload error: " . getUploadError($file['error']);
    }
}

// Function to get upload error message
function getUploadError($error_code) {
    $errors = array(
        UPLOAD_ERR_INI_SIZE => 'File exceeds upload_max_filesize directive in php.ini',
        UPLOAD_ERR_FORM_SIZE => 'File exceeds MAX_FILE_SIZE directive in HTML form',
        UPLOAD_ERR_PARTIAL => 'File was only partially uploaded',
        UPLOAD_ERR_NO_FILE => 'No file was uploaded',
        UPLOAD_ERR_NO_TMP_DIR => 'Missing temporary folder',
        UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk',
        UPLOAD_ERR_EXTENSION => 'File upload stopped by extension'
    );
    return $errors[$error_code] ?? 'Unknown upload error';
}

// Get recent uploads
$recent_sql = "SELECT * FROM files WHERE user_id = '$user_id' ORDER BY upload_date DESC LIMIT 5";
$recent_result = mysqli_query($conn, $recent_sql);

// Helper function for file icons
function getFileIcon($filetype) {
    if (strpos($filetype, 'image') !== false) return 'fas fa-file-image';
    if (strpos($filetype, 'video') !== false) return 'fas fa-file-video';
    if (strpos($filetype, 'audio') !== false) return 'fas fa-file-audio';
    if (strpos($filetype, 'pdf') !== false) return 'fas fa-file-pdf';
    if (strpos($filetype, 'word') !== false || strpos($filetype, 'doc') !== false) return 'fas fa-file-word';
    if (strpos($filetype, 'excel') !== false || strpos($filetype, 'sheet') !== false) return 'fas fa-file-excel';
    if (strpos($filetype, 'powerpoint') !== false || strpos($filetype, 'presentation') !== false) return 'fas fa-file-powerpoint';
    if (strpos($filetype, 'zip') !== false || strpos($filetype, 'compressed') !== false) return 'fas fa-file-archive';
    if (strpos($filetype, 'text') !== false || strpos($filetype, 'txt') !== false) return 'fas fa-file-alt';
    return 'fas fa-file';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Files - DriveSync</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* ===== GLOBAL STYLES ===== */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #000000;
            color: #FFFFFF;
            line-height: 1.6;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* ===== NAVBAR ===== */
        .navbar {
            background-color: #111111;
            padding: 1rem 0;
            border-bottom: 2px solid #FFD700;
            position: sticky;
            top: 0;
            z-index: 1000;
            backdrop-filter: blur(10px);
        }

        .nav-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.5rem;
            font-weight: bold;
            text-decoration: none;
        }

        .logo i {
            color: #FFD700;
            font-size: 1.8rem;
        }

        .logo-text {
            background: linear-gradient(45deg, #FFD700, #FFA500);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }

        .nav-links {
            display: flex;
            gap: 1.5rem;
            align-items: center;
        }

        .nav-link {
            color: #FFFFFF;
            text-decoration: none;
            font-weight: 500;
            padding: 8px 15px;
            border-radius: 5px;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .nav-link:hover {
            color: #FFD700;
            background-color: rgba(255, 215, 0, 0.1);
        }

        .nav-link.active {
            color: #FFD700;
            background-color: rgba(255, 215, 0, 0.15);
        }

        .user-dropdown {
            position: relative;
        }

        .user-btn {
            display: flex;
            align-items: center;
            gap: 10px;
            background: none;
            border: none;
            color: #FFFFFF;
            cursor: pointer;
            padding: 8px 15px;
            border-radius: 5px;
            transition: all 0.3s ease;
        }

        .user-btn:hover {
            background-color: rgba(255, 215, 0, 0.1);
            color: #FFD700;
        }

        .user-avatar {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            background-color: #FFD700;
            color: #000000;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 1rem;
        }

        .dropdown-menu {
            position: absolute;
            top: 100%;
            right: 0;
            background-color: #111111;
            border: 1px solid #333333;
            border-radius: 8px;
            padding: 10px 0;
            min-width: 200px;
            display: none;
            z-index: 1000;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        }

        .user-dropdown:hover .dropdown-menu {
            display: block;
        }

        .dropdown-item {
            display: block;
            padding: 10px 20px;
            color: #CCCCCC;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .dropdown-item:hover {
            background-color: rgba(255, 215, 0, 0.1);
            color: #FFD700;
        }

        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            color: #FFD700;
            font-size: 1.5rem;
            cursor: pointer;
        }

        /* ===== DASHBOARD LAYOUT ===== */
        .dashboard-wrapper {
            flex: 1;
            display: flex;
        }

        /* Sidebar */
        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, #111111 0%, #0A0A0A 100%);
            border-right: 1px solid #222222;
            padding: 2rem 1.5rem;
            position: sticky;
            top: 70px;
            height: calc(100vh - 70px);
            overflow-y: auto;
        }

        .sidebar-profile {
            text-align: center;
            margin-bottom: 2rem;
            padding-bottom: 1.5rem;
            border-bottom: 1px solid #222222;
        }

        .sidebar-profile-pic {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #FFD700;
            margin-bottom: 1rem;
        }

        .sidebar-profile h4 {
            color: #FFFFFF;
            margin-bottom: 5px;
        }

        .sidebar-profile p {
            color: #888888;
            font-size: 0.9rem;
        }

        .sidebar-menu {
            list-style: none;
            margin-bottom: 2rem;
        }

        .sidebar-menu li {
            margin-bottom: 8px;
        }

        .sidebar-menu a {
            display: flex;
            align-items: center;
            gap: 12px;
            color: #CCCCCC;
            text-decoration: none;
            padding: 12px 15px;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .sidebar-menu a:hover {
            background-color: rgba(255, 215, 0, 0.1);
            color: #FFD700;
            transform: translateX(5px);
        }

        .sidebar-menu a.active {
            background-color: rgba(255, 215, 0, 0.15);
            color: #FFD700;
            border-left: 3px solid #FFD700;
        }

        .storage-info {
            background-color: #0A0A0A;
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
            border: 1px solid #222222;
        }

        .storage-label {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
            font-size: 0.9rem;
        }

        .storage-bar {
            height: 6px;
            background-color: #222222;
            border-radius: 3px;
            overflow: hidden;
        }

        .storage-fill {
            height: 100%;
            background: linear-gradient(90deg, #FFD700, #FFA500);
            border-radius: 3px;
        }

        /* ===== MAIN CONTENT ===== */
        .main-content {
            flex: 1;
            padding: 2rem;
            background-color: #0A0A0A;
            overflow-y: auto;
        }

        .page-header {
            margin-bottom: 2rem;
            padding-bottom: 1.5rem;
            border-bottom: 1px solid #222222;
        }

        .page-header h1 {
            color: #FFD700;
            font-size: 2.2rem;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        /* Upload Area */
        .upload-container {
            max-width: 800px;
            margin: 0 auto;
        }

        .upload-card {
            background: linear-gradient(135deg, #111111, #0A0A0A);
            border-radius: 15px;
            border: 2px dashed #333333;
            padding: 3rem 2rem;
            text-align: center;
            transition: all 0.3s ease;
            margin-bottom: 2rem;
        }

        .upload-card:hover {
            border-color: #FFD700;
            background: linear-gradient(135deg, #1a1a1a, #0A0A0A);
        }

        .upload-card.drag-over {
            border-color: #FFD700;
            background: linear-gradient(135deg, #1a1a1a, #111111);
            transform: scale(1.02);
        }

        .upload-icon {
            font-size: 4rem;
            color: #FFD700;
            margin-bottom: 1.5rem;
        }

        .upload-card h3 {
            color: #FFFFFF;
            margin-bottom: 1rem;
            font-size: 1.5rem;
        }

        .upload-card p {
            color: #AAAAAA;
            margin-bottom: 2rem;
            font-size: 1rem;
        }

        .file-input-wrapper {
            position: relative;
            display: inline-block;
        }

        .file-input {
            position: absolute;
            left: 0;
            top: 0;
            opacity: 0;
            width: 100%;
            height: 100%;
            cursor: pointer;
        }

        .file-label {
            display: inline-block;
            background: linear-gradient(135deg, #FFD700 0%, #FFA500 100%);
            color: #000000;
            padding: 15px 30px;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .file-label:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(255, 215, 0, 0.3);
        }

        .selected-file {
            margin-top: 1.5rem;
            padding: 1rem;
            background-color: rgba(255, 215, 0, 0.1);
            border-radius: 8px;
            border: 1px solid rgba(255, 215, 0, 0.2);
            display: none;
        }

        .selected-file.show {
            display: block;
            animation: fadeIn 0.3s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .file-preview {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .file-preview-icon {
            font-size: 2.5rem;
            color: #FFD700;
        }

        .file-info h4 {
            color: #FFFFFF;
            margin-bottom: 5px;
        }

        .file-info p {
            color: #AAAAAA;
            font-size: 0.9rem;
            margin: 0;
        }

        .upload-btn {
            display: block;
            width: 100%;
            background: linear-gradient(135deg, #4CAF50 0%, #2E7D32 100%);
            color: #FFFFFF;
            border: none;
            padding: 15px;
            border-radius: 8px;
            font-size: 1.1rem;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 1.5rem;
        }

        .upload-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(76, 175, 80, 0.3);
        }

        .upload-btn:disabled {
            background: #666666;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }

        /* File Restrictions */
        .file-restrictions {
            background-color: #0A0A0A;
            border-radius: 10px;
            padding: 1.5rem;
            margin-top: 2rem;
            border: 1px solid #222222;
        }

        .file-restrictions h4 {
            color: #FFD700;
            margin-bottom: 1rem;
            font-size: 1.2rem;
        }

        .restrictions-list {
            list-style: none;
        }

        .restrictions-list li {
            color: #AAAAAA;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .restrictions-list i {
            color: #FFD700;
            font-size: 0.9rem;
        }

        /* Recent Uploads */
        .recent-uploads {
            margin-top: 3rem;
        }

        .recent-uploads h3 {
            color: #FFD700;
            margin-bottom: 1.5rem;
            font-size: 1.5rem;
        }

        .recent-files {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 1.5rem;
        }

        .recent-file-card {
            background: #111111;
            border-radius: 10px;
            padding: 1.5rem;
            border: 1px solid #222222;
            transition: all 0.3s ease;
        }

        .recent-file-card:hover {
            border-color: #FFD700;
            transform: translateY(-5px);
        }

        .recent-file-icon {
            font-size: 2.5rem;
            color: #FFD700;
            margin-bottom: 1rem;
        }

        .recent-file-info h4 {
            color: #FFFFFF;
            margin-bottom: 5px;
            font-size: 1rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .recent-file-info p {
            color: #AAAAAA;
            font-size: 0.85rem;
            margin: 0;
        }

        /* Alerts */
        .alert {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 2rem;
            border-left: 4px solid;
            display: flex;
            align-items: center;
            gap: 12px;
            animation: slideIn 0.3s ease;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .alert-success {
            background-color: rgba(76, 175, 80, 0.1);
            border-color: #4CAF50;
            color: #A5D6A7;
        }

        .alert-error {
            background-color: rgba(255, 82, 82, 0.1);
            border-color: #FF5252;
            color: #FF8A80;
        }

        /* ===== FOOTER ===== */
        footer {
            background-color: #050505;
            padding: 2rem;
            border-top: 1px solid #222222;
            margin-top: auto;
        }

        .footer-content {
            max-width: 1400px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 2rem;
        }

        .footer-logo {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .footer-links {
            display: flex;
            gap: 1.5rem;
            flex-wrap: wrap;
        }

        .footer-links a {
            color: #888888;
            text-decoration: none;
            transition: color 0.3s ease;
            font-size: 0.9rem;
        }

        .footer-links a:hover {
            color: #FFD700;
        }

        .copyright {
            color: #666666;
            font-size: 0.9rem;
            text-align: center;
            width: 100%;
            margin-top: 1rem;
        }

        /* ===== RESPONSIVE DESIGN ===== */
        @media (max-width: 1024px) {
            .nav-container, .footer-content {
                padding: 0 1.5rem;
            }
            
            .main-content {
                padding: 1.5rem;
            }
            
            .upload-card {
                padding: 2rem 1.5rem;
            }
        }

        @media (max-width: 768px) {
            .mobile-menu-btn {
                display: block;
            }
            
            .nav-links {
                position: fixed;
                top: 70px;
                left: 0;
                right: 0;
                background-color: #111111;
                flex-direction: column;
                padding: 2rem;
                gap: 1rem;
                transform: translateY(-100%);
                opacity: 0;
                visibility: hidden;
                transition: all 0.3s ease;
                border-bottom: 2px solid #FFD700;
            }
            
            .nav-links.active {
                transform: translateY(0);
                opacity: 1;
                visibility: visible;
            }
            
            .dashboard-wrapper {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                height: auto;
                position: static;
                border-right: none;
                border-bottom: 1px solid #222222;
            }
            
            .sidebar-menu {
                display: flex;
                flex-wrap: wrap;
                gap: 0.5rem;
            }
            
            .sidebar-menu li {
                flex: 1;
                min-width: 120px;
            }
            
            .sidebar-menu a {
                justify-content: center;
                text-align: center;
            }
            
            .recent-files {
                grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            }
            
            .footer-content {
                flex-direction: column;
                text-align: center;
                gap: 1rem;
            }
        }

        @media (max-width: 480px) {
            .nav-container {
                padding: 0 1rem;
            }
            
            .main-content {
                padding: 1rem;
            }
            
            .page-header h1 {
                font-size: 1.8rem;
            }
            
            .upload-card {
                padding: 1.5rem 1rem;
            }
            
            .upload-icon {
                font-size: 3rem;
            }
            
            .file-label {
                padding: 12px 25px;
                font-size: 0.9rem;
            }
            
            .recent-files {
                grid-template-columns: 1fr;
            }
        }

        /* ===== SCROLL BAR ===== */
        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: #111111;
        }

        ::-webkit-scrollbar-thumb {
            background: #FFD700;
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: #FFA500;
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar">
        <div class="nav-container">
            <a href="../../index.php" class="logo">
                <i class="fas fa-cloud"></i>
                <span class="logo-text">DriveSync</span>
            </a>
            
            <button class="mobile-menu-btn" id="mobileMenuBtn">
                <i class="fas fa-bars"></i>
            </button>
            
            <div class="nav-links" id="navLinks">
                <a href="../../index.php" class="nav-link">
                    <i class="fas fa-home"></i> Home
                </a>
                <a href="files.php" class="nav-link">
                    <i class="fas fa-folder"></i> My Files
                </a>
                <a href="upload.php" class="nav-link active">
                    <i class="fas fa-upload"></i> Upload
                </a>
                <a href="shared.php" class="nav-link">
                    <i class="fas fa-share-alt"></i> Shared
                </a>
                
                <!-- User Dropdown -->
                <div class="user-dropdown">
                    <button class="user-btn">
                        <div class="user-avatar">
                            <?php 
                            $first_letter = isset($_SESSION['user_name']) ? strtoupper(substr($_SESSION['user_name'], 0, 1)) : 'U';
                            echo $first_letter;
                            ?>
                        </div>
                        <span><?php echo $_SESSION['user_name'] ?? 'User'; ?></span>
                        <i class="fas fa-chevron-down"></i>
                    </button>
                    
                    <div class="dropdown-menu">
                        <a href="profile.php" class="dropdown-item">
                            <i class="fas fa-user"></i> My Profile
                        </a>
                        <a href="change-password.php" class="dropdown-item">
                            <i class="fas fa-key"></i> Change Password
                        </a>
                        <div class="dropdown-divider"></div>
                        <a href="../auth/logout.php" class="dropdown-item" onclick="return confirm('Are you sure you want to logout?')">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <!-- Dashboard Wrapper -->
    <div class="dashboard-wrapper">
        <!-- Sidebar -->
        <aside class="sidebar">
            <!-- User Profile -->
            <div class="sidebar-profile">
                <div class="user-avatar" style="width: 80px; height: 80px; margin: 0 auto 15px; background: #FFD700; color: #000; display: flex; align-items: center; justify-content: center; font-size: 2rem; font-weight: bold; border-radius: 50%;">
                    <?php 
                    $first_letter = isset($_SESSION['user_name']) ? strtoupper(substr($_SESSION['user_name'], 0, 1)) : 'U';
                    echo $first_letter;
                    ?>
                </div>
                <h4><?php echo $_SESSION['user_name'] ?? 'User'; ?></h4>
                <p><?php echo $_SESSION['user_email'] ?? 'user@example.com'; ?></p>
            </div>
            
            <!-- Storage Info -->
            <div class="storage-info">
                <div class="storage-label">
                    <span>Storage Used</span>
                    <span>
                        <?php 
                        $size_sql = "SELECT SUM(filesize) as total_size FROM files WHERE user_id = '$user_id'";
                        $size_result = mysqli_query($conn, $size_sql);
                        $size_row = mysqli_fetch_assoc($size_result);
                        $storage_used = $size_row['total_size'] ?: 0;
                        echo formatFileSize($storage_used) . ' / 100 GB';
                        ?>
                    </span>
                </div>
                <div class="storage-bar">
                    <div class="storage-fill" style="width: <?php echo min(($storage_used / (100 * 1024 * 1024 * 1024)) * 100, 100); ?>%"></div>
                </div>
            </div>
            
            <!-- Navigation Menu -->
            <ul class="sidebar-menu">
                <li>
                    <a href="files.php">
                        <i class="fas fa-folder"></i> My Files
                    </a>
                </li>
                <li>
                    <a href="upload.php" class="active">
                        <i class="fas fa-upload"></i> Upload Files
                    </a>
                </li>
                <li>
                    <a href="shared.php">
                        <i class="fas fa-share-alt"></i> Shared Files
                    </a>
                </li>
                <li>
                    <a href="profile.php">
                        <i class="fas fa-user"></i> My Profile
                    </a>
                </li>
                <li>
                    <a href="change-password.php">
                        <i class="fas fa-key"></i> Change Password
                    </a>
                </li>
                <li>
                    <a href="../auth/logout.php" onclick="return confirm('Are you sure you want to logout?')">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </li>
            </ul>
            
            <!-- Quick Stats -->
            <div class="storage-info">
                <h4 style="color: #FFD700; margin-bottom: 15px; font-size: 0.9rem;">Upload Stats</h4>
                <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                    <span style="color: #CCCCCC; font-size: 0.9rem;">Max File Size</span>
                    <span style="color: #FFD700; font-weight: bold;">1 GB</span>
                </div>
                <div style="display: flex; justify-content: space-between;">
                    <span style="color: #CCCCCC; font-size: 0.9rem;">Allowed Types</span>
                    <span style="color: #FFD700; font-weight: bold;">All</span>
                </div>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Page Header -->
            <div class="page-header">
                <h1>
                    <i class="fas fa-cloud-upload-alt"></i> Upload Files
                </h1>
                
                <?php if ($upload_message): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i>
                        <span><?php echo htmlspecialchars($upload_message); ?></span>
                        <span style="margin-left: auto; font-size: 0.9rem;">Redirecting to My Files...</span>
                    </div>
                <?php endif; ?>
                
                <?php if ($upload_error): ?>
                    <div class="alert alert-error">
                        <i class="fas fa-exclamation-circle"></i>
                        <span><?php echo htmlspecialchars($upload_error); ?></span>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- Upload Container -->
            <div class="upload-container">
                <!-- Upload Card -->
                <div class="upload-card" id="uploadArea">
                    <div class="upload-icon">
                        <i class="fas fa-cloud-upload-alt"></i>
                    </div>
                    
                    <h3>Drag & Drop Files Here</h3>
                    <p>or click to browse files from your computer</p>
                    
                    <form method="POST" enctype="multipart/form-data" id="uploadForm">
                        <div class="file-input-wrapper">
                            <input type="file" name="file" id="fileInput" class="file-input" onchange="handleFileSelect()">
                            <label for="fileInput" class="file-label">
                                <i class="fas fa-folder-open"></i> Browse Files
                            </label>
                        </div>
                        
                        <!-- Selected File Preview -->
                        <div class="selected-file" id="selectedFile">
                            <div class="file-preview">
                                <i class="fas fa-file file-preview-icon" id="fileIcon"></i>
                                <div class="file-info">
                                    <h4 id="fileName">No file selected</h4>
                                    <p id="fileSize">0 KB</p>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Upload Button -->
                        <button type="submit" class="upload-btn" id="uploadBtn" disabled>
                            <i class="fas fa-upload"></i> Upload File
                        </button>
                    </form>
                </div>
                
                <!-- File Restrictions -->
                <div class="file-restrictions">
                    <h4><i class="fas fa-info-circle"></i> File Upload Guidelines</h4>
                    <ul class="restrictions-list">
                        <li><i class="fas fa-check-circle"></i> Maximum file size: 1 GB</li>
                        <li><i class="fas fa-check-circle"></i> Supported formats: All file types</li>
                        <li><i class="fas fa-check-circle"></i> Secure encryption: 256-bit AES</li>
                        <li><i class="fas fa-check-circle"></i> Automatic virus scanning</li>
                        <li><i class="fas fa-check-circle"></i> Shareable links generation</li>
                    </ul>
                </div>
                
                <!-- Recent Uploads -->
                <?php if (mysqli_num_rows($recent_result) > 0): ?>
                <div class="recent-uploads">
                    <h3><i class="fas fa-history"></i> Recently Uploaded</h3>
                    <div class="recent-files">
                        <?php while ($recent = mysqli_fetch_assoc($recent_result)): ?>
                        <div class="recent-file-card">
                            <div class="recent-file-icon">
                                <i class="<?php echo getFileIcon($recent['filetype']); ?>"></i>
                            </div>
                            <div class="recent-file-info">
                                <h4 title="<?php echo htmlspecialchars($recent['filename']); ?>">
                                    <?php 
                                    $short_name = htmlspecialchars($recent['filename']);
                                    echo strlen($short_name) > 20 ? substr($short_name, 0, 20) . '...' : $short_name;
                                    ?>
                                </h4>
                                <p><?php echo date('d M, h:i A', strtotime($recent['upload_date'])); ?></p>
                            </div>
                        </div>
                        <?php endwhile; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <!-- Footer -->
    <footer>
        <div class="footer-content">
            <div class="footer-logo">
                <i class="fas fa-cloud" style="color: #FFD700;"></i>
                <span style="color: #FFD700; font-weight: bold;">DriveSync</span>
            </div>
            
            <div class="footer-links">
                <a href="../../index.php">Home</a>
                <a href="files.php">My Files</a>
                <a href="upload.php">Upload</a>
                <a href="profile.php">Profile</a>
                <a href="#">Help</a>
                <a href="#">Privacy</a>
                <a href="#">Terms</a>
            </div>
            
            <p class="copyright">
                &copy; 2024 DriveSync. All rights reserved. | Secure Cloud Storage Solution
            </p>
        </div>
    </footer>

    <script>
        // Mobile Menu Toggle
        const mobileMenuBtn = document.getElementById('mobileMenuBtn');
        const navLinks = document.getElementById('navLinks');
        
        mobileMenuBtn.addEventListener('click', function() {
            navLinks.classList.toggle('active');
            mobileMenuBtn.innerHTML = navLinks.classList.contains('active') 
                ? '<i class="fas fa-times"></i>' 
                : '<i class="fas fa-bars"></i>';
        });

        // Close mobile menu when clicking outside
        document.addEventListener('click', function(event) {
            if (!mobileMenuBtn.contains(event.target) && !navLinks.contains(event.target)) {
                navLinks.classList.remove('active');
                mobileMenuBtn.innerHTML = '<i class="fas fa-bars"></i>';
            }
        });

        // File upload functionality
        const uploadArea = document.getElementById('uploadArea');
        const fileInput = document.getElementById('fileInput');
        const selectedFile = document.getElementById('selectedFile');
        const fileName = document.getElementById('fileName');
        const fileSize = document.getElementById('fileSize');
        const fileIcon = document.getElementById('fileIcon');
        const uploadBtn = document.getElementById('uploadBtn');
        const uploadForm = document.getElementById('uploadForm');

        // Drag and drop functionality
        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            uploadArea.addEventListener(eventName, preventDefaults, false);
        });

        function preventDefaults(e) {
            e.preventDefault();
            e.stopPropagation();
        }

        ['dragenter', 'dragover'].forEach(eventName => {
            uploadArea.addEventListener(eventName, highlight, false);
        });

        ['dragleave', 'drop'].forEach(eventName => {
            uploadArea.addEventListener(eventName, unhighlight, false);
        });

        function highlight() {
            uploadArea.classList.add('drag-over');
        }

        function unhighlight() {
            uploadArea.classList.remove('drag-over');
        }

        // Handle dropped files
        uploadArea.addEventListener('drop', handleDrop, false);

        function handleDrop(e) {
            const dt = e.dataTransfer;
            const files = dt.files;
            
            if (files.length > 0) {
                fileInput.files = files;
                handleFileSelect();
            }
        }

        // Handle file selection
        function handleFileSelect() {
            const file = fileInput.files[0];
            
            if (file) {
                // Show selected file info
                selectedFile.classList.add('show');
                fileName.textContent = file.name;
                fileSize.textContent = formatFileSize(file.size);
                
                // Set appropriate icon
                fileIcon.className = getFileIcon(file.type) + ' file-preview-icon';
                
                // Enable upload button
                uploadBtn.disabled = false;
                
                // Check file size
                const maxSize = 1024 * 1024 * 1024; // 1GB
                if (file.size > maxSize) {
                    uploadBtn.disabled = true;
                    selectedFile.style.backgroundColor = 'rgba(255, 82, 82, 0.1)';
                    selectedFile.style.borderColor = 'rgba(255, 82, 82, 0.3)';
                    fileName.innerHTML = `${file.name} <span style="color: #FF5252;">(File too large)</span>`;
                } else {
                    selectedFile.style.backgroundColor = '';
                    selectedFile.style.borderColor = '';
                }
            } else {
                selectedFile.classList.remove('show');
                uploadBtn.disabled = true;
            }
        }

        // Format file size
        function formatFileSize(bytes) {
            if (bytes === 0) return '0 B';
            const k = 1024;
            const sizes = ['B', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
        }

        // Get file icon based on type
        function getFileIcon(filetype) {
            if (!filetype) return 'fas fa-file';
            
            const type = filetype.toLowerCase();
            if (type.includes('image')) return 'fas fa-file-image';
            if (type.includes('video')) return 'fas fa-file-video';
            if (type.includes('audio')) return 'fas fa-file-audio';
            if (type.includes('pdf')) return 'fas fa-file-pdf';
            if (type.includes('word') || type.includes('doc')) return 'fas fa-file-word';
            if (type.includes('excel') || type.includes('sheet')) return 'fas fa-file-excel';
            if (type.includes('powerpoint') || type.includes('presentation')) return 'fas fa-file-powerpoint';
            if (type.includes('zip') || type.includes('compressed')) return 'fas fa-file-archive';
            if (type.includes('text') || type.includes('txt')) return 'fas fa-file-alt';
            return 'fas fa-file';
        }

        // Form submission with progress indication
        uploadForm.addEventListener('submit', function(e) {
            if (!fileInput.files[0]) {
                e.preventDefault();
                return;
            }
            
            // Show loading state
            uploadBtn.disabled = true;
            uploadBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Uploading...';
            
            // Change upload area style
            uploadArea.style.borderStyle = 'solid';
            uploadArea.style.borderColor = '#FFD700';
            uploadArea.style.backgroundColor = 'rgba(255, 215, 0, 0.05)';
        });

        // Update storage bar
        document.addEventListener('DOMContentLoaded', function() {
            const storageFill = document.querySelector('.storage-fill');
            const usedSpan = document.querySelector('.storage-info .storage-label span:last-child');
            
            if (storageFill && usedSpan) {
                const width = storageFill.style.width;
                if (parseFloat(width) > 90) {
                    storageFill.style.background = 'linear-gradient(90deg, #FF5252, #FF8A80)';
                } else if (parseFloat(width) > 70) {
                    storageFill.style.background = 'linear-gradient(90deg, #FFA500, #FFD700)';
                }
            }
        });
    </script>
</body>
</html>

<?php
// Helper function for file size formatting
function formatFileSize($bytes) {
    if ($bytes == 0) return '0 B';
    
    $units = ['B', 'KB', 'MB', 'GB'];
    $i = 0;
    while ($bytes >= 1024 && $i < 3) {
        $bytes /= 1024;
        $i++;
    }
    return round($bytes, 2) . ' ' . $units[$i];
}