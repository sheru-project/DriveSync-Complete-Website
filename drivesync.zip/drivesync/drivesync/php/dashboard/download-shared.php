<?php
require_once '../config/database.php';
require_once '../config/session.php';

if (isset($_GET['link'])) {
    $share_link = mysqli_real_escape_string($conn, $_GET['link']);
    
    $sql = "SELECT * FROM files WHERE share_link = '$share_link'";
    $result = mysqli_query($conn, $sql);
    
    if (mysqli_num_rows($result) == 1) {
        $file = mysqli_fetch_assoc($result);
        $filepath = $file['filepath'];
        $filename = $file['filename'];
        
        if (file_exists($filepath)) {
            // Increment download count
            
            // Download file
            header('Content-Description: File Transfer');
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="' . basename($filename) . '"');
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            header('Content-Length: ' . filesize($filepath));
            readfile($filepath);
            exit;
        }
    }
}

// If download fails, redirect
header("Location: shared-file.php?link=" . $_GET['link']);
exit();
?>