<?php
require_once '../config/database.php';
require_once '../config/session.php';

$error = '';
$file_data = null;

if (isset($_GET['link'])) {
    $share_link = mysqli_real_escape_string($conn, $_GET['link']);
    
    $sql = "SELECT f.*, u.first_name, u.last_name 
            FROM files f 
            JOIN users u ON f.user_id = u.id 
            WHERE f.share_link = '$share_link'";
    
    $result = mysqli_query($conn, $sql);
    
    if (mysqli_num_rows($result) == 1) {
        $file_data = mysqli_fetch_assoc($result);
        
        // Increment view count (you can add a view_count column to files table)
    } else {
        $error = "Invalid or expired share link!";
    }
} else {
    $error = "No share link provided!";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Shared File - DriveSync</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>
    <nav class="navbar">
        <div class="nav-container">
            <div class="logo">
                <i class="fas fa-cloud" style="color: #FFD700;"></i>
                <span class="logo-text" style="color: #FFD700;">DriveSync</span>
            </div>
        </div>
    </nav>
    
    <div class="shared-file-container">
        <?php if ($error): ?>
            <div class="shared-error">
                <i class="fas fa-exclamation-triangle" style="font-size: 3rem; color: #FFD700;"></i>
                <h2>Link Error</h2>
                <p><?php echo $error; ?></p>
                <a href="../../index.php" class="btn-primary">Go to Homepage</a>
            </div>
        <?php elseif ($file_data): ?>
            <div class="shared-file-card">
                <div class="shared-file-icon">
                    <i class="<?php echo getFileIcon($file_data['filetype']); ?>" 
                       style="font-size: 4rem; color: #FFD700;"></i>
                </div>
                
                <h2><?php echo htmlspecialchars($file_data['filename']); ?></h2>
                
                <div class="file-meta">
                    <p><i class="fas fa-user"></i> Shared by: 
                       <?php echo $file_data['first_name'] . ' ' . $file_data['last_name']; ?>
                    </p>
                    <p><i class="fas fa-file"></i> Size: 
                       <?php echo formatFileSize($file_data['filesize']); ?>
                    </p>
                    <p><i class="fas fa-calendar"></i> Uploaded: 
                       <?php echo date('d M Y', strtotime($file_data['upload_date'])); ?>
                    </p>
                </div>
                
                <!-- File Preview (for images and PDFs) -->
                <?php if (strpos($file_data['filetype'], 'image') !== false): ?>
                <div class="file-preview">
                    <img src="<?php echo $file_data['filepath']; ?>" 
                         alt="Preview" style="max-width: 100%; max-height: 400px;">
                </div>
                <?php endif; ?>
                
                <!-- Download Button -->
                <div class="download-section">
                    <a href="download-shared.php?link=<?php echo $share_link; ?>" 
                       class="btn-primary btn-large">
                        <i class="fas fa-download"></i> Download File
                    </a>
                    
                    <p class="download-note">
                        <i class="fas fa-info-circle"></i> 
                        This file will be downloaded to your device
                    </p>
                </div>
                
                <!-- Create Account CTA -->
                <div class="cta-box">
                    <h3><i class="fas fa-cloud-upload-alt"></i> Want your own cloud storage?</h3>
                    <p>Sign up for free and get 100GB of storage</p>
                    <a href="../auth/signup.php" class="btn-secondary">
                        <i class="fas fa-user-plus"></i> Create Free Account
                    </a>
                </div>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>