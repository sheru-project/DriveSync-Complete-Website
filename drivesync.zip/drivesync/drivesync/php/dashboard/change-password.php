<?php
// Start session
require_once '../config/session.php';
require_once '../config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Get user data
$sql = "SELECT * FROM users WHERE id = '$user_id'";
$result = mysqli_query($conn, $sql);
$user = mysqli_fetch_assoc($result);

// Handle password change
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    // Validate inputs
    if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
        $error = "All fields are required!";
    } elseif ($new_password !== $confirm_password) {
        $error = "New passwords do not match!";
    } elseif (strlen($new_password) < 8) {
        $error = "New password must be at least 8 characters long!";
    } elseif (!preg_match('/[A-Z]/', $new_password)) {
        $error = "New password must contain at least one uppercase letter!";
    } elseif (!preg_match('/[a-z]/', $new_password)) {
        $error = "New password must contain at least one lowercase letter!";
    } elseif (!preg_match('/[0-9]/', $new_password)) {
        $error = "New password must contain at least one number!";
    } elseif (!preg_match('/[^A-Za-z0-9]/', $new_password)) {
        $error = "New password must contain at least one special character!";
    } else {
        // Verify current password
        if (password_verify($current_password, $user['password'])) {
            // Check if new password is same as current
            if (password_verify($new_password, $user['password'])) {
                $error = "New password cannot be same as current password!";
            } else {
                // Hash new password
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                
                // Update password in database
                $update_sql = "UPDATE users SET password = '$hashed_password' WHERE id = '$user_id'";
                
                if (mysqli_query($conn, $update_sql)) {
                    $_SESSION['message'] = "Password changed successfully!";
                    
                    // Send email notification (optional)
                    // sendPasswordChangeEmail($user['email'], $user['first_name']);
                    
                    // Logout user for security
                    session_destroy();
                    header("Location: ../auth/login.php?message=password_changed");
                    exit();
                } else {
                    $error = "Error updating password: " . mysqli_error($conn);
                }
            }
        } else {
            $error = "Current password is incorrect!";
        }
    }
}

// Check for success message from login page
if (isset($_GET['message']) && $_GET['message'] == 'password_changed') {
    $message = "Password changed successfully! Please login with your new password.";
}

// Get storage usage
$storage_sql = "SELECT SUM(filesize) as total_size FROM files WHERE user_id = '$user_id'";
$storage_result = mysqli_query($conn, $storage_sql);
$storage_data = mysqli_fetch_assoc($storage_result);
$storage_used = $storage_data['total_size'] ?: 0;
$storage_percentage = min(($storage_used / (5 * 1024 * 1024 * 1024)) * 100, 100);

// Helper function
function formatFileSize($bytes) {
    if ($bytes == 0) return '0 B';
    
    $units = ['B', 'KB', 'MB', 'GB'];
    $i = 0;
    while ($bytes >= 1024 && $i < 3) {
        $bytes /= 1024;
        $i++;
    }
    return round($bytes, 2) . ' ' . $units[$i];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password - DriveSync</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* ===== GLOBAL STYLES ===== */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #000000;
            color: #FFFFFF;
            line-height: 1.6;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* ===== NAVBAR ===== */
        .navbar {
            background-color: #111111;
            padding: 1rem 0;
            border-bottom: 2px solid #FFD700;
            position: sticky;
            top: 0;
            z-index: 1000;
            backdrop-filter: blur(10px);
        }

        .nav-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.5rem;
            font-weight: bold;
            text-decoration: none;
        }

        .logo i {
            color: #FFD700;
            font-size: 1.8rem;
        }

        .logo-text {
            background: linear-gradient(45deg, #FFD700, #FFA500);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }

        .nav-links {
            display: flex;
            gap: 1.5rem;
            align-items: center;
        }

        .nav-link {
            color: #FFFFFF;
            text-decoration: none;
            font-weight: 500;
            padding: 8px 15px;
            border-radius: 5px;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .nav-link:hover {
            color: #FFD700;
            background-color: rgba(255, 215, 0, 0.1);
        }

        .nav-link.active {
            color: #FFD700;
            background-color: rgba(255, 215, 0, 0.15);
        }

        .user-dropdown {
            position: relative;
        }

        .user-btn {
            display: flex;
            align-items: center;
            gap: 10px;
            background: none;
            border: none;
            color: #FFFFFF;
            cursor: pointer;
            padding: 8px 15px;
            border-radius: 5px;
            transition: all 0.3s ease;
        }

        .user-btn:hover {
            background-color: rgba(255, 215, 0, 0.1);
            color: #FFD700;
        }

        .user-avatar {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            background-color: #FFD700;
            color: #000000;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 1rem;
        }

        .dropdown-menu {
            position: absolute;
            top: 100%;
            right: 0;
            background-color: #111111;
            border: 1px solid #333333;
            border-radius: 8px;
            padding: 10px 0;
            min-width: 200px;
            display: none;
            z-index: 1000;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        }

        .user-dropdown:hover .dropdown-menu {
            display: block;
        }

        .dropdown-item {
            display: block;
            padding: 10px 20px;
            color: #CCCCCC;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .dropdown-item:hover {
            background-color: rgba(255, 215, 0, 0.1);
            color: #FFD700;
        }

        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            color: #FFD700;
            font-size: 1.5rem;
            cursor: pointer;
        }

        /* ===== DASHBOARD LAYOUT ===== */
        .dashboard-wrapper {
            flex: 1;
            display: flex;
        }

        /* Sidebar */
        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, #111111 0%, #0A0A0A 100%);
            border-right: 1px solid #222222;
            padding: 2rem 1.5rem;
            position: sticky;
            top: 70px;
            height: calc(100vh - 70px);
            overflow-y: auto;
        }

        .sidebar-profile {
            text-align: center;
            margin-bottom: 2rem;
            padding-bottom: 1.5rem;
            border-bottom: 1px solid #222222;
        }

        .profile-pic-container {
            position: relative;
            display: inline-block;
            margin-bottom: 1rem;
        }

        .sidebar-profile-pic {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #FFD700;
        }

        .sidebar-profile h4 {
            color: #FFFFFF;
            margin-bottom: 5px;
            font-size: 1.3rem;
        }

        .sidebar-profile p {
            color: #888888;
            font-size: 0.9rem;
        }

        .sidebar-menu {
            list-style: none;
            margin-bottom: 2rem;
        }

        .sidebar-menu li {
            margin-bottom: 8px;
        }

        .sidebar-menu a {
            display: flex;
            align-items: center;
            gap: 12px;
            color: #CCCCCC;
            text-decoration: none;
            padding: 12px 15px;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .sidebar-menu a:hover {
            background-color: rgba(255, 215, 0, 0.1);
            color: #FFD700;
            transform: translateX(5px);
        }

        .sidebar-menu a.active {
            background-color: rgba(255, 215, 0, 0.15);
            color: #FFD700;
            border-left: 3px solid #FFD700;
        }

        .storage-info {
            background-color: #0A0A0A;
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
            border: 1px solid #222222;
        }

        .storage-label {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
            font-size: 0.9rem;
        }

        .storage-bar {
            height: 6px;
            background-color: #222222;
            border-radius: 3px;
            overflow: hidden;
        }

        .storage-fill {
            height: 100%;
            background: linear-gradient(90deg, #FFD700, #FFA500);
            border-radius: 3px;
        }

        /* ===== MAIN CONTENT ===== */
        .main-content {
            flex: 1;
            padding: 2rem;
            background-color: #0A0A0A;
            overflow-y: auto;
        }

        .page-header {
            margin-bottom: 2rem;
            padding-bottom: 1.5rem;
            border-bottom: 1px solid #222222;
        }

        .page-header h1 {
            color: #FFD700;
            font-size: 2.2rem;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        /* Alerts */
        .alert {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 2rem;
            border-left: 4px solid;
            display: flex;
            align-items: center;
            gap: 12px;
            animation: slideIn 0.3s ease;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .alert-success {
            background-color: rgba(76, 175, 80, 0.1);
            border-color: #4CAF50;
            color: #A5D6A7;
        }

        .alert-error {
            background-color: rgba(255, 82, 82, 0.1);
            border-color: #FF5252;
            color: #FF8A80;
        }

        /* Change Password Card */
        .change-password-card {
            background: linear-gradient(135deg, #111111, #0A0A0A);
            padding: 2.5rem;
            border-radius: 12px;
            border: 1px solid #222222;
            max-width: 500px;
            margin: 0 auto;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        }

        .change-password-card h2 {
            color: #FFD700;
            margin-bottom: 1.5rem;
            font-size: 1.8rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .change-password-card h2 i {
            font-size: 1.5rem;
        }

        /* Form Styles */
        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #CCCCCC;
            font-weight: 500;
        }

        .password-input-group {
            position: relative;
        }

        .form-control {
            width: 100%;
            padding: 12px 15px;
            background-color: #111111;
            border: 1px solid #333333;
            border-radius: 8px;
            color: #FFFFFF;
            font-size: 1rem;
            transition: all 0.3s ease;
            padding-right: 45px;
        }

        .form-control:focus {
            outline: none;
            border-color: #FFD700;
            box-shadow: 0 0 0 2px rgba(255, 215, 0, 0.1);
        }

        .password-toggle {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: #888888;
            cursor: pointer;
            font-size: 1rem;
            transition: color 0.3s ease;
        }

        .password-toggle:hover {
            color: #FFD700;
        }

        /* Password Requirements */
        .password-requirements {
            background-color: #0A0A0A;
            border: 1px solid #333333;
            border-radius: 8px;
            padding: 1.5rem;
            margin-bottom: 2rem;
        }

        .password-requirements h4 {
            color: #FFD700;
            margin-bottom: 1rem;
            font-size: 1rem;
        }

        .requirement-list {
            list-style: none;
        }

        .requirement-list li {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 8px;
            color: #888888;
            font-size: 0.9rem;
        }

        .requirement-list li i {
            font-size: 0.8rem;
            width: 16px;
        }

        .requirement-list li.valid {
            color: #4CAF50;
        }

        .requirement-list li.invalid {
            color: #FF5252;
        }

        /* Buttons */
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.3s ease;
            width: 100%;
            justify-content: center;
        }

        .btn-primary {
            background: linear-gradient(135deg, #FFD700 0%, #FFA500 100%);
            color: #000000;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(255, 215, 0, 0.4);
        }

        .btn-secondary {
            background-color: #222222;
            color: #FFFFFF;
            border: 1px solid #333333;
            margin-top: 10px;
        }

        .btn-secondary:hover {
            background-color: #333333;
            border-color: #444444;
        }

        /* Security Tips */
        .security-tips {
            margin-top: 2rem;
            padding-top: 1.5rem;
            border-top: 1px solid #222222;
        }

        .security-tips h4 {
            color: #FFD700;
            margin-bottom: 1rem;
            font-size: 1rem;
        }

        .tips-list {
            list-style: none;
        }

        .tips-list li {
            display: flex;
            align-items: flex-start;
            gap: 10px;
            margin-bottom: 10px;
            color: #888888;
            font-size: 0.9rem;
        }

        .tips-list li i {
            color: #FFD700;
            font-size: 0.8rem;
            margin-top: 3px;
            flex-shrink: 0;
        }

        /* ===== FOOTER ===== */
        footer {
            background-color: #050505;
            padding: 2rem;
            border-top: 1px solid #222222;
            margin-top: auto;
        }

        .footer-content {
            max-width: 1400px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 2rem;
        }

        .footer-logo {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .footer-links {
            display: flex;
            gap: 1.5rem;
            flex-wrap: wrap;
        }

        .footer-links a {
            color: #888888;
            text-decoration: none;
            transition: color 0.3s ease;
            font-size: 0.9rem;
        }

        .footer-links a:hover {
            color: #FFD700;
        }

        .copyright {
            color: #666666;
            font-size: 0.9rem;
            text-align: center;
            width: 100%;
            margin-top: 1rem;
        }

        /* ===== RESPONSIVE DESIGN ===== */
        @media (max-width: 1024px) {
            .nav-container, .footer-content {
                padding: 0 1.5rem;
            }
            
            .main-content {
                padding: 1.5rem;
            }
        }

        @media (max-width: 768px) {
            .mobile-menu-btn {
                display: block;
            }
            
            .nav-links {
                position: fixed;
                top: 70px;
                left: 0;
                right: 0;
                background-color: #111111;
                flex-direction: column;
                padding: 2rem;
                gap: 1rem;
                transform: translateY(-100%);
                opacity: 0;
                visibility: hidden;
                transition: all 0.3s ease;
                border-bottom: 2px solid #FFD700;
            }
            
            .nav-links.active {
                transform: translateY(0);
                opacity: 1;
                visibility: visible;
            }
            
            .dashboard-wrapper {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                height: auto;
                position: static;
                border-right: none;
                border-bottom: 1px solid #222222;
            }
            
            .sidebar-menu {
                display: flex;
                flex-wrap: wrap;
                gap: 0.5rem;
            }
            
            .sidebar-menu li {
                flex: 1;
                min-width: 120px;
            }
            
            .sidebar-menu a {
                justify-content: center;
                text-align: center;
            }
            
            .change-password-card {
                padding: 2rem;
            }
            
            .footer-content {
                flex-direction: column;
                text-align: center;
                gap: 1rem;
            }
        }

        @media (max-width: 480px) {
            .nav-container {
                padding: 0 1rem;
            }
            
            .main-content {
                padding: 1rem;
            }
            
            .page-header h1 {
                font-size: 1.8rem;
            }
            
            .change-password-card {
                padding: 1.5rem;
            }
        }

        /* ===== SCROLL BAR ===== */
        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: #111111;
        }

        ::-webkit-scrollbar-thumb {
            background: #FFD700;
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: #FFA500;
        }

        /* Password Strength Meter */
        .password-strength {
            margin-top: 5px;
            height: 4px;
            background-color: #333333;
            border-radius: 2px;
            overflow: hidden;
        }

        .strength-bar {
            height: 100%;
            width: 0;
            border-radius: 2px;
            transition: all 0.3s ease;
        }

        .strength-weak {
            background-color: #FF5252;
            width: 33%;
        }

        .strength-medium {
            background-color: #FFA500;
            width: 66%;
        }

        .strength-strong {
            background-color: #4CAF50;
            width: 100%;
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar">
        <div class="nav-container">
            <a href="../../index.php" class="logo">
                <i class="fas fa-cloud"></i>
                <span class="logo-text">DriveSync</span>
            </a>
            
            <button class="mobile-menu-btn" id="mobileMenuBtn">
                <i class="fas fa-bars"></i>
            </button>
            
            <div class="nav-links" id="navLinks">
                <a href="../../index.php" class="nav-link">
                    <i class="fas fa-home"></i> Home
                </a>
                <a href="files.php" class="nav-link">
                    <i class="fas fa-folder"></i> My Files
                </a>
                <a href="upload.php" class="nav-link">
                    <i class="fas fa-upload"></i> Upload
                </a>
                <a href="shared.php" class="nav-link">
                    <i class="fas fa-share-alt"></i> Shared
                </a>
                
                <!-- User Dropdown -->
                <div class="user-dropdown">
                    <button class="user-btn">
                        <div class="user-avatar">
                            <?php 
                            if ($user['profile_pic'] && $user['profile_pic'] != 'default.png') {
                                echo '<img src="../../assets/uploads/profile_pics/' . htmlspecialchars($user['profile_pic']) . '" 
                                     style="width:100%;height:100%;border-radius:50%;object-fit:cover;">';
                            } else {
                                $first_letter = isset($user['first_name']) ? strtoupper(substr($user['first_name'], 0, 1)) : 'U';
                                echo $first_letter;
                            }
                            ?>
                        </div>
                        <span><?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?></span>
                        <i class="fas fa-chevron-down"></i>
                    </button>
                    
                    <div class="dropdown-menu">
                        <a href="profile.php" class="dropdown-item">
                            <i class="fas fa-user"></i> My Profile
                        </a>
                        <a href="change-password.php" class="dropdown-item">
                            <i class="fas fa-key"></i> Change Password
                        </a>
                        <div class="dropdown-divider"></div>
                        <a href="../auth/logout.php" class="dropdown-item" onclick="return confirm('Are you sure you want to logout?')">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <!-- Dashboard Wrapper -->
    <div class="dashboard-wrapper">
        <!-- Sidebar -->
        <aside class="sidebar">
            <!-- User Profile -->
            <div class="sidebar-profile">
                <div class="profile-pic-container">
                    <?php
                    $profile_pic_path = '../../assets/uploads/profile_pics/' . $user['profile_pic'];
                    if ($user['profile_pic'] && $user['profile_pic'] != 'default.png' && file_exists($profile_pic_path)) {
                        echo '<img src="' . $profile_pic_path . '" alt="Profile Picture" class="sidebar-profile-pic">';
                    } else {
                        echo '<div class="sidebar-profile-pic" style="background:#FFD700;color:#000;display:flex;align-items:center;justify-content:center;font-size:2rem;font-weight:bold;">';
                        echo strtoupper(substr($user['first_name'], 0, 1));
                        echo '</div>';
                    }
                    ?>
                </div>
                <h4><?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?></h4>
                <p><?php echo htmlspecialchars($user['email']); ?></p>
                <p style="color: #888; font-size: 0.8rem; margin-top: 5px;">
                    <i class="fas fa-shield-alt"></i> Change Password
                </p>
            </div>
            
            <!-- Storage Info -->
            <div class="storage-info">
                <div class="storage-label">
                    <span>Storage Used</span>
                    <span><?php echo formatFileSize($storage_used) . ' / 100 GB'; ?></span>
                </div>
                <div class="storage-bar">
                    <div class="storage-fill" style="width: <?php echo $storage_percentage; ?>%"></div>
                </div>
                <div style="text-align: center; margin-top: 10px; color: #888; font-size: 0.9rem;">
                    <?php echo round($storage_percentage, 2); ?>% used
                </div>
            </div>
            
            <!-- Navigation Menu -->
            <ul class="sidebar-menu">
                <li>
                    <a href="files.php">
                        <i class="fas fa-folder"></i> My Files
                    </a>
                </li>
                <li>
                    <a href="upload.php">
                        <i class="fas fa-upload"></i> Upload Files
                    </a>
                </li>
                <li>
                    <a href="shared.php">
                        <i class="fas fa-share-alt"></i> Shared Files
                    </a>
                </li>
                <li>
                    <a href="profile.php">
                        <i class="fas fa-user"></i> My Profile
                    </a>
                </li>
                <li>
                    <a href="change-password.php" class="active">
                        <i class="fas fa-key"></i> Change Password
                    </a>
                </li>
                <li>
                    <a href="../auth/logout.php" onclick="return confirm('Are you sure you want to logout?')">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </li>
            </ul>
            
            <!-- Security Stats -->
            <div class="storage-info">
                <h4 style="color: #FFD700; margin-bottom: 15px; font-size: 0.9rem;">Security Status</h4>
                <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
                    <i class="fas fa-check-circle" style="color: #4CAF50;"></i>
                    <span style="color: #CCCCCC; font-size: 0.9rem;">Account Active</span>
                </div>
                <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
                    <i class="fas fa-envelope" style="color: <?php echo $user['is_verified'] ? '#4CAF50' : '#FFA500'; ?>;"></i>
                    <span style="color: #CCCCCC; font-size: 0.9rem;">
                        <?php echo $user['is_verified'] ? 'Email Verified' : 'Email Not Verified'; ?>
                    </span>
                </div>
                <div style="display: flex; align-items: center; gap: 10px;">
                    <i class="fas fa-history" style="color: #888;"></i>
                    <span style="color: #CCCCCC; font-size: 0.9rem;">
                        Last updated: <?php echo date('d M', strtotime($user['created_at'])); ?>
                    </span>
                </div>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Page Header -->
            <div class="page-header">
                <h1>
                    <i class="fas fa-key"></i> Change Password
                </h1>
                
                <?php if ($message): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i>
                        <span><?php echo htmlspecialchars($message); ?></span>
                    </div>
                <?php endif; ?>
                
                <?php if ($error): ?>
                    <div class="alert alert-error">
                        <i class="fas fa-exclamation-circle"></i>
                        <span><?php echo htmlspecialchars($error); ?></span>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- Change Password Card -->
            <div class="change-password-card">
                <h2><i class="fas fa-user-shield"></i> Update Your Password</h2>
                
                <!-- Password Requirements -->
                <div class="password-requirements">
                    <h4><i class="fas fa-info-circle"></i> Password Requirements:</h4>
                    <ul class="requirement-list" id="requirementList">
                        <li id="req-length" class="invalid">
                            <i class="fas fa-times"></i> At least 8 characters
                        </li>
                        <li id="req-uppercase" class="invalid">
                            <i class="fas fa-times"></i> One uppercase letter
                        </li>
                        <li id="req-lowercase" class="invalid">
                            <i class="fas fa-times"></i> One lowercase letter
                        </li>
                        <li id="req-number" class="invalid">
                            <i class="fas fa-times"></i> One number
                        </li>
                        <li id="req-special" class="invalid">
                            <i class="fas fa-times"></i> One special character
                        </li>
                        <li id="req-match" class="invalid">
                            <i class="fas fa-times"></i> Passwords match
                        </li>
                    </ul>
                </div>
                
                <!-- Change Password Form -->
                <form method="POST" action="" id="changePasswordForm">
                    <div class="form-group">
                        <label for="current_password">
                            <i class="fas fa-lock"></i> Current Password
                        </label>
                        <div class="password-input-group">
                            <input type="password" id="current_password" name="current_password" 
                                   class="form-control" placeholder="Enter your current password" required>
                            <button type="button" class="password-toggle" onclick="togglePassword('current_password', this)">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="new_password">
                            <i class="fas fa-lock"></i> New Password
                        </label>
                        <div class="password-input-group">
                            <input type="password" id="new_password" name="new_password" 
                                   class="form-control" placeholder="Enter new password" required
                                   oninput="validatePassword()">
                            <button type="button" class="password-toggle" onclick="togglePassword('new_password', this)">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                        <div class="password-strength">
                            <div class="strength-bar" id="strengthBar"></div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="confirm_password">
                            <i class="fas fa-lock"></i> Confirm New Password
                        </label>
                        <div class="password-input-group">
                            <input type="password" id="confirm_password" name="confirm_password" 
                                   class="form-control" placeholder="Confirm new password" required
                                   oninput="validatePassword()">
                            <button type="button" class="password-toggle" onclick="togglePassword('confirm_password', this)">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-primary" id="submitBtn" disabled>
                        <i class="fas fa-key"></i> Change Password
                    </button>
                    
                    <a href="profile.php" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Back to Profile
                    </a>
                </form>
                
                <!-- Security Tips -->
                <div class="security-tips">
                    <h4><i class="fas fa-lightbulb"></i> Security Tips:</h4>
                    <ul class="tips-list">
                        <li>
                            <i class="fas fa-check"></i>
                            <span>Use a unique password that you don't use elsewhere</span>
                        </li>
                        <li>
                            <i class="fas fa-check"></i>
                            <span>Consider using a password manager to generate and store passwords</span>
                        </li>
                        <li>
                            <i class="fas fa-check"></i>
                            <span>Change your password regularly (every 90 days is recommended)</span>
                        </li>
                        <li>
                            <i class="fas fa-check"></i>
                            <span>Never share your password with anyone</span>
                        </li>
                        <li>
                            <i class="fas fa-check"></i>
                            <span>You will be logged out after changing your password for security</span>
                        </li>
                    </ul>
                </div>
            </div>
        </main>
    </div>

    <!-- Footer -->
    <footer>
        <div class="footer-content">
            <div class="footer-logo">
                <i class="fas fa-cloud" style="color: #FFD700;"></i>
                <span style="color: #FFD700; font-weight: bold;">DriveSync</span>
            </div>
            
            <div class="footer-links">
                <a href="../../index.php">Home</a>
                <a href="files.php">My Files</a>
                <a href="upload.php">Upload</a>
                <a href="shared.php">Shared</a>
                <a href="profile.php">Profile</a>
                <a href="change-password.php">Change Password</a>
                <a href="#">Privacy</a>
                <a href="#">Terms</a>
            </div>
            
            <p class="copyright">
                &copy; 2024 DriveSync. All rights reserved. | Secure Cloud Storage Solution
            </p>
        </div>
    </footer>

    <script>
        // Mobile Menu Toggle
        const mobileMenuBtn = document.getElementById('mobileMenuBtn');
        const navLinks = document.getElementById('navLinks');
        
        mobileMenuBtn.addEventListener('click', function() {
            navLinks.classList.toggle('active');
            mobileMenuBtn.innerHTML = navLinks.classList.contains('active') 
                ? '<i class="fas fa-times"></i>' 
                : '<i class="fas fa-bars"></i>';
        });

        // Close mobile menu when clicking outside
        document.addEventListener('click', function(event) {
            if (!mobileMenuBtn.contains(event.target) && !navLinks.contains(event.target)) {
                navLinks.classList.remove('active');
                mobileMenuBtn.innerHTML = '<i class="fas fa-bars"></i>';
            }
        });

        // Toggle password visibility
        function togglePassword(inputId, button) {
            const input = document.getElementById(inputId);
            const icon = button.querySelector('i');
            
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        }

        // Password validation function
        function validatePassword() {
            const password = document.getElementById('new_password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            const submitBtn = document.getElementById('submitBtn');
            const strengthBar = document.getElementById('strengthBar');
            
            // Reset all requirements
            const requirements = {
                length: { element: document.getElementById('req-length'), valid: false },
                uppercase: { element: document.getElementById('req-uppercase'), valid: false },
                lowercase: { element: document.getElementById('req-lowercase'), valid: false },
                number: { element: document.getElementById('req-number'), valid: false },
                special: { element: document.getElementById('req-special'), valid: false },
                match: { element: document.getElementById('req-match'), valid: false }
            };
            
            // Check each requirement
            requirements.length.valid = password.length >= 8;
            requirements.uppercase.valid = /[A-Z]/.test(password);
            requirements.lowercase.valid = /[a-z]/.test(password);
            requirements.number.valid = /[0-9]/.test(password);
            requirements.special.valid = /[^A-Za-z0-9]/.test(password);
            requirements.match.valid = password === confirmPassword && password.length > 0;
            
            // Update requirement UI
            let validCount = 0;
            for (const key in requirements) {
                const req = requirements[key];
                if (req.valid) {
                    req.element.classList.remove('invalid');
                    req.element.classList.add('valid');
                    req.element.querySelector('i').className = 'fas fa-check';
                    validCount++;
                } else {
                    req.element.classList.remove('valid');
                    req.element.classList.add('invalid');
                    req.element.querySelector('i').className = 'fas fa-times';
                }
            }
            
            // Update password strength meter
            let strength = 0;
            if (requirements.length.valid) strength++;
            if (requirements.uppercase.valid) strength++;
            if (requirements.lowercase.valid) strength++;
            if (requirements.number.valid) strength++;
            if (requirements.special.valid) strength++;
            
            strengthBar.className = 'strength-bar';
            if (strength <= 2) {
                strengthBar.classList.add('strength-weak');
            } else if (strength <= 4) {
                strengthBar.classList.add('strength-medium');
            } else {
                strengthBar.classList.add('strength-strong');
            }
            
            // Enable/disable submit button
            submitBtn.disabled = validCount !== 6;
            
            return validCount === 6;
        }

        // Form validation on submit
        document.getElementById('changePasswordForm').addEventListener('submit', function(event) {
            const currentPassword = document.getElementById('current_password').value.trim();
            const newPassword = document.getElementById('new_password').value.trim();
            const confirmPassword = document.getElementById('confirm_password').value.trim();
            
            // Basic validation
            if (!currentPassword || !newPassword || !confirmPassword) {
                event.preventDefault();
                alert('Please fill in all fields.');
                return false;
            }
            
            if (!validatePassword()) {
                event.preventDefault();
                alert('Please fix all password requirements before submitting.');
                return false;
            }
            
            // Additional validation
            if (newPassword === currentPassword) {
                event.preventDefault();
                alert('New password cannot be same as current password.');
                return false;
            }
            
            // Show loading state
            const submitBtn = document.getElementById('submitBtn');
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Changing Password...';
            submitBtn.disabled = true;
            
            return true;
        });

        // Initialize validation on page load
        document.addEventListener('DOMContentLoaded', function() {
            validatePassword();
            
            // Update storage bar color based on usage
            const storageFill = document.querySelector('.storage-fill');
            const percentage = <?php echo $storage_percentage; ?>;
            
            if (storageFill) {
                if (percentage > 90) {
                    storageFill.style.background = 'linear-gradient(90deg, #FF5252, #FF8A80)';
                } else if (percentage > 70) {
                    storageFill.style.background = 'linear-gradient(90deg, #FFA500, #FFD700)';
                } else {
                    storageFill.style.background = 'linear-gradient(90deg, #FFD700, #4CAF50)';
                }
            }
            
            // Auto-hide alerts after 5 seconds
            setTimeout(function() {
                const alerts = document.querySelectorAll('.alert');
                alerts.forEach(alert => {
                    alert.style.opacity = '0';
                    alert.style.transform = 'translateY(-10px)';
                    setTimeout(() => alert.remove(), 300);
                });
            }, 5000);
        });

        // Prevent form submission on Enter key in input fields
        document.querySelectorAll('.form-control').forEach(input => {
            input.addEventListener('keypress', function(event) {
                if (event.key === 'Enter') {
                    event.preventDefault();
                }
            });
        });

        // Show password strength in real-time
        document.getElementById('new_password').addEventListener('input', function() {
            const password = this.value;
            let strength = 0;
            
            if (password.length >= 8) strength++;
            if (/[A-Z]/.test(password)) strength++;
            if (/[a-z]/.test(password)) strength++;
            if (/[0-9]/.test(password)) strength++;
            if (/[^A-Za-z0-9]/.test(password)) strength++;
            
            const strengthText = document.getElementById('strengthText');
            if (strength <= 2) {
                strengthText.textContent = 'Weak';
                strengthText.style.color = '#FF5252';
            } else if (strength <= 4) {
                strengthText.textContent = 'Medium';
                strengthText.style.color = '#FFA500';
            } else {
                strengthText.textContent = 'Strong';
                strengthText.style.color = '#4CAF50';
            }
        });
    </script>
</body>
</html>