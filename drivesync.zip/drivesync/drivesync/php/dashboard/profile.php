<?php
// Start session
require_once '../config/session.php';
require_once '../config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Get user data
$sql = "SELECT * FROM users WHERE id = '$user_id'";
$result = mysqli_query($conn, $sql);
$user = mysqli_fetch_assoc($result);

// Handle profile picture upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['profile_pic'])) {
    $upload_dir = '../../assets/uploads/profile_pics/';
    
    // Create directory if not exists
    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }
    
    $file_name = $_FILES['profile_pic']['name'];
    $file_tmp = $_FILES['profile_pic']['tmp_name'];
    $file_size = $_FILES['profile_pic']['size'];
    $file_error = $_FILES['profile_pic']['error'];
    
    // Get file extension
    $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
    
    // Allowed extensions
    $allowed_ext = array('jpg', 'jpeg', 'png', 'gif');
    
    if (in_array($file_ext, $allowed_ext)) {
        if ($file_error === 0) {
            if ($file_size <= 5242880) { // 5MB limit
                // Generate unique filename
                $new_file_name = "profile_" . $user_id . "_" . time() . "." . $file_ext;
                $file_destination = $upload_dir . $new_file_name;
                
                // Move uploaded file
                if (move_uploaded_file($file_tmp, $file_destination)) {
                    // Delete old profile pic if not default
                    if ($user['profile_pic'] != 'default.png' && file_exists($upload_dir . $user['profile_pic'])) {
                        unlink($upload_dir . $user['profile_pic']);
                    }
                    
                    // Update database
                    $update_sql = "UPDATE users SET profile_pic = '$new_file_name' WHERE id = '$user_id'";
                    if (mysqli_query($conn, $update_sql)) {
                        $_SESSION['message'] = "Profile picture updated successfully!";
                        $_SESSION['user_profile_pic'] = $new_file_name; // Update session
                        header("Location: profile.php");
                        exit();
                    } else {
                        $_SESSION['error'] = "Database update failed.";
                    }
                } else {
                    $_SESSION['error'] = "File upload failed.";
                }
            } else {
                $_SESSION['error'] = "File size too large. Maximum 5MB allowed.";
            }
        } else {
            $_SESSION['error'] = "Error uploading file.";
        }
    } else {
        $_SESSION['error'] = "Invalid file type. Only JPG, JPEG, PNG & GIF allowed.";
    }
}

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $first_name = mysqli_real_escape_string($conn, $_POST['first_name']);
    $last_name = mysqli_real_escape_string($conn, $_POST['last_name']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    
    $update_sql = "UPDATE users SET 
                    first_name = '$first_name',
                    last_name = '$last_name',
                    phone = '$phone'
                    WHERE id = '$user_id'";
    
    if (mysqli_query($conn, $update_sql)) {
        $_SESSION['message'] = "Profile updated successfully!";
        $_SESSION['user_name'] = $first_name . ' ' . $last_name; // Update session
        header("Location: profile.php");
        exit();
    } else {
        $_SESSION['error'] = "Error updating profile: " . mysqli_error($conn);
    }
}

// Check messages
$message = isset($_SESSION['message']) ? $_SESSION['message'] : '';
$error = isset($_SESSION['error']) ? $_SESSION['error'] : '';

// Clear messages
unset($_SESSION['message']);
unset($_SESSION['error']);

// Helper functions
function formatFileSize($bytes) {
    if ($bytes == 0) return '0 B';
    
    $units = ['B', 'KB', 'MB', 'GB'];
    $i = 0;
    while ($bytes >= 1024 && $i < 3) {
        $bytes /= 1024;
        $i++;
    }
    return round($bytes, 2) . ' ' . $units[$i];
}

// Get storage usage
$storage_sql = "SELECT SUM(filesize) as total_size FROM files WHERE user_id = '$user_id'";
$storage_result = mysqli_query($conn, $storage_sql);
$storage_data = mysqli_fetch_assoc($storage_result);
$storage_used = $storage_data['total_size'] ?: 0;
$storage_percentage = min(($storage_used / (100 * 1024 * 1024 * 1024)) * 100, 100);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - DriveSync</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* ===== GLOBAL STYLES ===== */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #000000;
            color: #FFFFFF;
            line-height: 1.6;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* ===== NAVBAR ===== */
        .navbar {
            background-color: #111111;
            padding: 1rem 0;
            border-bottom: 2px solid #FFD700;
            position: sticky;
            top: 0;
            z-index: 1000;
            backdrop-filter: blur(10px);
        }

        .nav-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.5rem;
            font-weight: bold;
            text-decoration: none;
        }

        .logo i {
            color: #FFD700;
            font-size: 1.8rem;
        }

        .logo-text {
            background: linear-gradient(45deg, #FFD700, #FFA500);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }

        .nav-links {
            display: flex;
            gap: 1.5rem;
            align-items: center;
        }

        .nav-link {
            color: #FFFFFF;
            text-decoration: none;
            font-weight: 500;
            padding: 8px 15px;
            border-radius: 5px;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .nav-link:hover {
            color: #FFD700;
            background-color: rgba(255, 215, 0, 0.1);
        }

        .nav-link.active {
            color: #FFD700;
            background-color: rgba(255, 215, 0, 0.15);
        }

        .user-dropdown {
            position: relative;
        }

        .user-btn {
            display: flex;
            align-items: center;
            gap: 10px;
            background: none;
            border: none;
            color: #FFFFFF;
            cursor: pointer;
            padding: 8px 15px;
            border-radius: 5px;
            transition: all 0.3s ease;
        }

        .user-btn:hover {
            background-color: rgba(255, 215, 0, 0.1);
            color: #FFD700;
        }

        .user-avatar {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            background-color: #FFD700;
            color: #000000;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 1rem;
        }

        .dropdown-menu {
            position: absolute;
            top: 100%;
            right: 0;
            background-color: #111111;
            border: 1px solid #333333;
            border-radius: 8px;
            padding: 10px 0;
            min-width: 200px;
            display: none;
            z-index: 1000;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        }

        .user-dropdown:hover .dropdown-menu {
            display: block;
        }

        .dropdown-item {
            display: block;
            padding: 10px 20px;
            color: #CCCCCC;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .dropdown-item:hover {
            background-color: rgba(255, 215, 0, 0.1);
            color: #FFD700;
        }

        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            color: #FFD700;
            font-size: 1.5rem;
            cursor: pointer;
        }

        /* ===== DASHBOARD LAYOUT ===== */
        .dashboard-wrapper {
            flex: 1;
            display: flex;
        }

        /* Sidebar */
        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, #111111 0%, #0A0A0A 100%);
            border-right: 1px solid #222222;
            padding: 2rem 1.5rem;
            position: sticky;
            top: 70px;
            height: calc(100vh - 70px);
            overflow-y: auto;
        }

        .sidebar-profile {
            text-align: center;
            margin-bottom: 2rem;
            padding-bottom: 1.5rem;
            border-bottom: 1px solid #222222;
        }

        .profile-pic-container {
            position: relative;
            display: inline-block;
            margin-bottom: 1rem;
        }

        .sidebar-profile-pic {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #FFD700;
        }

        .profile-pic-overlay {
            position: absolute;
            bottom: 5px;
            right: 5px;
            background: #FFD700;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .profile-pic-overlay:hover {
            transform: scale(1.1);
        }

        .profile-pic-overlay i {
            color: #000;
            font-size: 14px;
        }

        .sidebar-profile h4 {
            color: #FFFFFF;
            margin-bottom: 5px;
            font-size: 1.3rem;
        }

        .sidebar-profile p {
            color: #888888;
            font-size: 0.9rem;
        }

        .sidebar-menu {
            list-style: none;
            margin-bottom: 2rem;
        }

        .sidebar-menu li {
            margin-bottom: 8px;
        }

        .sidebar-menu a {
            display: flex;
            align-items: center;
            gap: 12px;
            color: #CCCCCC;
            text-decoration: none;
            padding: 12px 15px;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .sidebar-menu a:hover {
            background-color: rgba(255, 215, 0, 0.1);
            color: #FFD700;
            transform: translateX(5px);
        }

        .sidebar-menu a.active {
            background-color: rgba(255, 215, 0, 0.15);
            color: #FFD700;
            border-left: 3px solid #FFD700;
        }

        .storage-info {
            background-color: #0A0A0A;
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
            border: 1px solid #222222;
        }

        .storage-label {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
            font-size: 0.9rem;
        }

        .storage-bar {
            height: 6px;
            background-color: #222222;
            border-radius: 3px;
            overflow: hidden;
        }

        .storage-fill {
            height: 100%;
            background: linear-gradient(90deg, #FFD700, #FFA500);
            border-radius: 3px;
        }

        /* ===== MAIN CONTENT ===== */
        .main-content {
            flex: 1;
            padding: 2rem;
            background-color: #0A0A0A;
            overflow-y: auto;
        }

        .page-header {
            margin-bottom: 2rem;
            padding-bottom: 1.5rem;
            border-bottom: 1px solid #222222;
        }

        .page-header h1 {
            color: #FFD700;
            font-size: 2.2rem;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        /* Alerts */
        .alert {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 2rem;
            border-left: 4px solid;
            display: flex;
            align-items: center;
            gap: 12px;
            animation: slideIn 0.3s ease;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .alert-success {
            background-color: rgba(76, 175, 80, 0.1);
            border-color: #4CAF50;
            color: #A5D6A7;
        }

        .alert-error {
            background-color: rgba(255, 82, 82, 0.1);
            border-color: #FF5252;
            color: #FF8A80;
        }

        /* Profile Cards */
        .profile-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
            margin-bottom: 2rem;
        }

        .profile-card {
            background: linear-gradient(135deg, #111111, #0A0A0A);
            padding: 2rem;
            border-radius: 12px;
            border: 1px solid #222222;
        }

        .profile-card h2 {
            color: #FFD700;
            margin-bottom: 1.5rem;
            font-size: 1.5rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .profile-card h2 i {
            font-size: 1.2rem;
        }

        /* Form Styles */
        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #CCCCCC;
            font-weight: 500;
        }

        .form-control {
            width: 100%;
            padding: 12px 15px;
            background-color: #111111;
            border: 1px solid #333333;
            border-radius: 8px;
            color: #FFFFFF;
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        .form-control:focus {
            outline: none;
            border-color: #FFD700;
            box-shadow: 0 0 0 2px rgba(255, 215, 0, 0.1);
        }

        .form-control[readonly] {
            background-color: #0A0A0A;
            color: #888888;
            cursor: not-allowed;
        }

        /* Buttons */
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .btn-primary {
            background: linear-gradient(135deg, #FFD700 0%, #FFA500 100%);
            color: #000000;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(255, 215, 0, 0.4);
        }

        .btn-secondary {
            background-color: #222222;
            color: #FFFFFF;
            border: 1px solid #333333;
        }

        .btn-secondary:hover {
            background-color: #333333;
            border-color: #444444;
        }

        .btn-danger {
            background-color: #d32f2f;
            color: #FFFFFF;
        }

        .btn-danger:hover {
            background-color: #c62828;
        }

        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
            margin-top: 2rem;
        }

        .stat-item {
            background: #111111;
            padding: 1.5rem;
            border-radius: 8px;
            border: 1px solid #222222;
            text-align: center;
        }

        .stat-value {
            color: #FFD700;
            font-size: 2rem;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .stat-label {
            color: #888888;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        /* Modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.8);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }

        .modal-content {
            background: linear-gradient(135deg, #111111, #0A0A0A);
            width: 90%;
            max-width: 500px;
            border-radius: 12px;
            border: 1px solid #222222;
            overflow: hidden;
        }

        .modal-header {
            padding: 1.5rem;
            border-bottom: 1px solid #222222;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .modal-header h3 {
            color: #FFD700;
            margin: 0;
        }

        .modal-close {
            background: none;
            border: none;
            color: #CCCCCC;
            font-size: 1.5rem;
            cursor: pointer;
            transition: color 0.3s ease;
        }

        .modal-close:hover {
            color: #FFD700;
        }

        .modal-body {
            padding: 1.5rem;
        }

        /* File Upload */
        .file-upload-container {
            border: 2px dashed #444444;
            border-radius: 8px;
            padding: 2rem;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .file-upload-container:hover {
            border-color: #FFD700;
            background-color: rgba(255, 215, 0, 0.05);
        }

        .file-upload-icon {
            font-size: 3rem;
            color: #FFD700;
            margin-bottom: 1rem;
        }

        .file-upload-input {
            display: none;
        }

        .file-preview {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: cover;
            margin: 0 auto 1rem;
            border: 3px solid #FFD700;
        }

        /* ===== FOOTER ===== */
        footer {
            background-color: #050505;
            padding: 2rem;
            border-top: 1px solid #222222;
            margin-top: auto;
        }

        .footer-content {
            max-width: 1400px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 2rem;
        }

        .footer-logo {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .footer-links {
            display: flex;
            gap: 1.5rem;
            flex-wrap: wrap;
        }

        .footer-links a {
            color: #888888;
            text-decoration: none;
            transition: color 0.3s ease;
            font-size: 0.9rem;
        }

        .footer-links a:hover {
            color: #FFD700;
        }

        .copyright {
            color: #666666;
            font-size: 0.9rem;
            text-align: center;
            width: 100%;
            margin-top: 1rem;
        }

        /* ===== RESPONSIVE DESIGN ===== */
        @media (max-width: 1024px) {
            .nav-container, .footer-content {
                padding: 0 1.5rem;
            }
            
            .main-content {
                padding: 1.5rem;
            }
            
            .profile-grid {
                gap: 1.5rem;
            }
        }

        @media (max-width: 768px) {
            .mobile-menu-btn {
                display: block;
            }
            
            .nav-links {
                position: fixed;
                top: 70px;
                left: 0;
                right: 0;
                background-color: #111111;
                flex-direction: column;
                padding: 2rem;
                gap: 1rem;
                transform: translateY(-100%);
                opacity: 0;
                visibility: hidden;
                transition: all 0.3s ease;
                border-bottom: 2px solid #FFD700;
            }
            
            .nav-links.active {
                transform: translateY(0);
                opacity: 1;
                visibility: visible;
            }
            
            .dashboard-wrapper {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                height: auto;
                position: static;
                border-right: none;
                border-bottom: 1px solid #222222;
            }
            
            .sidebar-menu {
                display: flex;
                flex-wrap: wrap;
                gap: 0.5rem;
            }
            
            .sidebar-menu li {
                flex: 1;
                min-width: 120px;
            }
            
            .sidebar-menu a {
                justify-content: center;
                text-align: center;
            }
            
            .profile-grid {
                grid-template-columns: 1fr;
            }
            
            .footer-content {
                flex-direction: column;
                text-align: center;
                gap: 1rem;
            }
        }

        @media (max-width: 480px) {
            .nav-container {
                padding: 0 1rem;
            }
            
            .main-content {
                padding: 1rem;
            }
            
            .page-header h1 {
                font-size: 1.8rem;
            }
            
            .profile-card {
                padding: 1.5rem;
            }
            
            .modal-content {
                width: 95%;
            }
        }

        /* ===== SCROLL BAR ===== */
        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: #111111;
        }

        ::-webkit-scrollbar-thumb {
            background: #FFD700;
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: #FFA500;
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar">
        <div class="nav-container">
            <a href="../../index.php" class="logo">
                <i class="fas fa-cloud"></i>
                <span class="logo-text">DriveSync</span>
            </a>
            
            <button class="mobile-menu-btn" id="mobileMenuBtn">
                <i class="fas fa-bars"></i>
            </button>
            
            <div class="nav-links" id="navLinks">
                <a href="../../index.php" class="nav-link">
                    <i class="fas fa-home"></i> Home
                </a>
                <a href="files.php" class="nav-link">
                    <i class="fas fa-folder"></i> My Files
                </a>
                <a href="upload.php" class="nav-link">
                    <i class="fas fa-upload"></i> Upload
                </a>
                <a href="shared.php" class="nav-link">
                    <i class="fas fa-share-alt"></i> Shared
                </a>
                
                <!-- User Dropdown -->
                <div class="user-dropdown">
                    <button class="user-btn">
                        <div class="user-avatar">
                            <?php 
                            if ($user['profile_pic'] && $user['profile_pic'] != 'default.png') {
                                echo '<img src="../../assets/uploads/profile_pics/' . htmlspecialchars($user['profile_pic']) . '" 
                                     style="width:100%;height:100%;border-radius:50%;object-fit:cover;">';
                            } else {
                                $first_letter = isset($user['first_name']) ? strtoupper(substr($user['first_name'], 0, 1)) : 'U';
                                echo $first_letter;
                            }
                            ?>
                        </div>
                        <span><?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?></span>
                        <i class="fas fa-chevron-down"></i>
                    </button>
                    
                    <div class="dropdown-menu">
                        <a href="profile.php" class="dropdown-item">
                            <i class="fas fa-user"></i> My Profile
                        </a>
                        <a href="change-password.php" class="dropdown-item">
                            <i class="fas fa-key"></i> Change Password
                        </a>
                        <div class="dropdown-divider"></div>
                        <a href="../auth/logout.php" class="dropdown-item" onclick="return confirm('Are you sure you want to logout?')">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <!-- Dashboard Wrapper -->
    <div class="dashboard-wrapper">
        <!-- Sidebar -->
        <aside class="sidebar">
            <!-- User Profile -->
            <div class="sidebar-profile">
                <div class="profile-pic-container">
                    <?php
                    $profile_pic_path = '../../assets/uploads/profile_pics/' . $user['profile_pic'];
                    if ($user['profile_pic'] && $user['profile_pic'] != 'default.png' && file_exists($profile_pic_path)) {
                        echo '<img src="' . $profile_pic_path . '" alt="Profile Picture" class="sidebar-profile-pic">';
                    } else {
                        echo '<div class="sidebar-profile-pic" style="background:#FFD700;color:#000;display:flex;align-items:center;justify-content:center;font-size:2.5rem;font-weight:bold;">';
                        echo strtoupper(substr($user['first_name'], 0, 1));
                        echo '</div>';
                    }
                    ?>
                    <div class="profile-pic-overlay" onclick="openProfilePicModal()">
                        <i class="fas fa-camera"></i>
                    </div>
                </div>
                <h4><?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?></h4>
                <p><?php echo htmlspecialchars($user['email']); ?></p>
                <p style="color: #888; font-size: 0.8rem; margin-top: 5px;">
                    Member since <?php echo date('d M Y', strtotime($user['created_at'])); ?>
                </p>
            </div>
            
            <!-- Storage Info -->
            <div class="storage-info">
                <div class="storage-label">
                    <span>Storage Used</span>
                    <span><?php echo formatFileSize($storage_used) . ' / 100 GB'; ?></span>
                </div>
                <div class="storage-bar">
                    <div class="storage-fill" style="width: <?php echo $storage_percentage; ?>%"></div>
                </div>
                <div style="text-align: center; margin-top: 10px; color: #888; font-size: 0.9rem;">
                    <?php echo round($storage_percentage, 2); ?>% used
                </div>
            </div>
            
            <!-- Navigation Menu -->
            <ul class="sidebar-menu">
                <li>
                    <a href="files.php">
                        <i class="fas fa-folder"></i> My Files
                    </a>
                </li>
                <li>
                    <a href="upload.php">
                        <i class="fas fa-upload"></i> Upload Files
                    </a>
                </li>
                <li>
                    <a href="shared.php">
                        <i class="fas fa-share-alt"></i> Shared Files
                    </a>
                </li>
                <li>
                    <a href="profile.php" class="active">
                        <i class="fas fa-user"></i> My Profile
                    </a>
                </li>
                <li>
                    <a href="change-password.php">
                        <i class="fas fa-key"></i> Change Password
                    </a>
                </li>
                <li>
                    <a href="../auth/logout.php" onclick="return confirm('Are you sure you want to logout?')">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </li>
            </ul>
            
            <!-- Quick Stats -->
            <div class="storage-info">
                <h4 style="color: #FFD700; margin-bottom: 15px; font-size: 0.9rem;">Account Stats</h4>
                <?php
                // Get file count
                $file_count_sql = "SELECT COUNT(*) as file_count FROM files WHERE user_id = '$user_id'";
                $file_count_result = mysqli_query($conn, $file_count_sql);
                $file_count = mysqli_fetch_assoc($file_count_result)['file_count'];
                
                // Get shared file count
                $shared_count_sql = "SELECT COUNT(*) as shared_count FROM files WHERE user_id = '$user_id' AND share_link IS NOT NULL";
                $shared_count_result = mysqli_query($conn, $shared_count_sql);
                $shared_count = mysqli_fetch_assoc($shared_count_result)['shared_count'];
                ?>
                <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                    <span style="color: #CCCCCC; font-size: 0.9rem;">Total Files</span>
                    <span style="color: #FFD700; font-weight: bold;"><?php echo $file_count; ?></span>
                </div>
                <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                    <span style="color: #CCCCCC; font-size: 0.9rem;">Shared Files</span>
                    <span style="color: #FFD700; font-weight: bold;"><?php echo $shared_count; ?></span>
                </div>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Page Header -->
            <div class="page-header">
                <h1>
                    <i class="fas fa-user-circle"></i> My Profile
                </h1>
                
                <?php if ($message): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i>
                        <span><?php echo htmlspecialchars($message); ?></span>
                    </div>
                <?php endif; ?>
                
                <?php if ($error): ?>
                    <div class="alert alert-error">
                        <i class="fas fa-exclamation-circle"></i>
                        <span><?php echo htmlspecialchars($error); ?></span>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- Profile Grid -->
            <div class="profile-grid">
                <!-- Profile Information Card -->
                <div class="profile-card">
                    <h2><i class="fas fa-user"></i> Profile Information</h2>
                    <form method="POST" action="">
                        <div class="form-group">
                            <label for="first_name">First Name</label>
                            <input type="text" id="first_name" name="first_name" 
                                   class="form-control" 
                                   value="<?php echo htmlspecialchars($user['first_name']); ?>" 
                                   required>
                        </div>
                        
                        <div class="form-group">
                            <label for="last_name">Last Name</label>
                            <input type="text" id="last_name" name="last_name" 
                                   class="form-control" 
                                   value="<?php echo htmlspecialchars($user['last_name']); ?>" 
                                   required>
                        </div>
                        
                        <div class="form-group">
                            <label for="email">Email Address</label>
                            <input type="email" id="email" class="form-control" 
                                   value="<?php echo htmlspecialchars($user['email']); ?>" 
                                   readonly>
                        </div>
                        
                        <div class="form-group">
                            <label for="phone">Phone Number</label>
                            <input type="tel" id="phone" name="phone" 
                                   class="form-control" 
                                   value="<?php echo htmlspecialchars($user['phone']); ?>" 
                                   placeholder="Enter phone number">
                        </div>
                        
                        <div class="form-group">
                            <label for="created_at">Member Since</label>
                            <input type="text" id="created_at" class="form-control" 
                                   value="<?php echo date('d M Y', strtotime($user['created_at'])); ?>" 
                                   readonly>
                        </div>
                        
                        <button type="submit" name="update_profile" class="btn btn-primary">
                            <i class="fas fa-save"></i> Update Profile
                        </button>
                    </form>
                </div>
                
                <!-- Account Stats Card -->
                <div class="profile-card">
                    <h2><i class="fas fa-chart-bar"></i> Account Statistics</h2>
                    
                    <div class="stats-grid">
                        <div class="stat-item">
                            <div class="stat-value"><?php echo $file_count; ?></div>
                            <div class="stat-label">Total Files</div>
                        </div>
                        
                        <div class="stat-item">
                            <div class="stat-value"><?php echo $shared_count; ?></div>
                            <div class="stat-label">Shared Files</div>
                        </div>
                        
                        <div class="stat-item">
                            <div class="stat-value"><?php echo formatFileSize($storage_used); ?></div>
                            <div class="stat-label">Storage Used</div>
                        </div>
                        
                        <div class="stat-item">
                            <div class="stat-value"><?php echo (5 * 1024 * 1024 * 1024) - $storage_used > 0 ? formatFileSize((5 * 1024 * 1024 * 1024) - $storage_used) : '0 B'; ?></div>
                            <div class="stat-label">Storage Left</div>
                        </div>
                    </div>
                    
                    <div style="margin-top: 2rem;">
                        <h3 style="color: #FFD700; margin-bottom: 1rem; font-size: 1.2rem;">
                            <i class="fas fa-key"></i> Account Security
                        </h3>
                        <a href="change-password.php" class="btn btn-secondary" style="margin-right: 10px;">
                            <i class="fas fa-key"></i> Change Password
                        </a>
                        <a href="../auth/logout.php" class="btn btn-danger" onclick="return confirm('Are you sure you want to logout?')">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </div>
                </div>
            </div>
            
            <!-- Recent Activity -->
            <div class="profile-card" style="margin-top: 2rem;">
                <h2><i class="fas fa-history"></i> Recent Activity</h2>
                
                <?php
                // Get recent uploads
                $recent_sql = "SELECT * FROM files WHERE user_id = '$user_id' 
                               ORDER BY upload_date DESC LIMIT 5";
                $recent_result = mysqli_query($conn, $recent_sql);
                
                if (mysqli_num_rows($recent_result) > 0) {
                    echo '<div style="overflow-x: auto;">';
                    echo '<table style="width: 100%; border-collapse: collapse; margin-top: 1rem;">';
                    echo '<thead>';
                    echo '<tr style="background: #0A0A0A;">';
                    echo '<th style="padding: 12px; text-align: left; color: #FFD700; border-bottom: 1px solid #222;">File Name</th>';
                    echo '<th style="padding: 12px; text-align: left; color: #FFD700; border-bottom: 1px solid #222;">Uploaded</th>';
                    echo '<th style="padding: 12px; text-align: left; color: #FFD700; border-bottom: 1px solid #222;">Size</th>';
                    echo '</tr>';
                    echo '</thead>';
                    echo '<tbody>';
                    
                    while ($file = mysqli_fetch_assoc($recent_result)) {
                        echo '<tr style="border-bottom: 1px solid #222;">';
                        echo '<td style="padding: 12px; color: #CCC;">' . htmlspecialchars($file['filename']) . '</td>';
                        echo '<td style="padding: 12px; color: #888;">' . date('d M Y', strtotime($file['upload_date'])) . '</td>';
                        echo '<td style="padding: 12px; color: #888;">' . formatFileSize($file['filesize']) . '</td>';
                        echo '</tr>';
                    }
                    
                    echo '</tbody>';
                    echo '</table>';
                    echo '</div>';
                    
                    echo '<div style="text-align: center; margin-top: 1.5rem;">';
                    echo '<a href="files.php" class="btn btn-secondary">';
                    echo '<i class="fas fa-folder"></i> View All Files';
                    echo '</a>';
                    echo '</div>';
                } else {
                    echo '<div style="text-align: center; padding: 3rem; color: #666;">';
                    echo '<i class="fas fa-folder-open" style="font-size: 3rem; margin-bottom: 1rem; display: block;"></i>';
                    echo '<p>No files uploaded yet.</p>';
                    echo '<a href="upload.php" class="btn btn-primary" style="margin-top: 1rem;">';
                    echo '<i class="fas fa-upload"></i> Upload First File';
                    echo '</a>';
                    echo '</div>';
                }
                ?>
            </div>
        </main>
    </div>

    <!-- Profile Picture Modal -->
    <div class="modal" id="profilePicModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-camera"></i> Update Profile Picture</h3>
                <button class="modal-close" onclick="closeProfilePicModal()">&times;</button>
            </div>
            <div class="modal-body">
                <form method="POST" action="" enctype="multipart/form-data">
                    <div class="file-upload-container" onclick="document.getElementById('profile_pic_input').click()">
                        <div class="file-upload-icon">
                            <i class="fas fa-cloud-upload-alt"></i>
                        </div>
                        <h4 style="color: #FFD700; margin-bottom: 10px;">Click to Upload</h4>
                        <p style="color: #888; margin-bottom: 15px;">JPG, JPEG, PNG, GIF (Max 5MB)</p>
                        
                        <img id="profile_preview" class="file-preview" 
                             src="<?php 
                             $profile_pic_path = '../../assets/uploads/profile_pics/' . $user['profile_pic'];
                             if ($user['profile_pic'] && $user['profile_pic'] != 'default.png' && file_exists($profile_pic_path)) {
                                 echo $profile_pic_path;
                             } else {
                                 echo 'data:image/svg+xml;base64,' . base64_encode('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="50" cy="50" r="50" fill="#FFD700"/><text x="50" y="60" text-anchor="middle" font-size="40" fill="#000">' . strtoupper(substr($user['first_name'], 0, 1)) . '</text></svg>');
                             }
                             ?>" 
                             alt="Profile Preview">
                        
                        <input type="file" id="profile_pic_input" name="profile_pic" 
                               class="file-upload-input" accept="image/*" 
                               onchange="previewProfileImage(event)">
                    </div>
                    
                    <div style="display: flex; gap: 10px; margin-top: 1.5rem;">
                        <button type="button" class="btn btn-secondary" onclick="closeProfilePicModal()" style="flex: 1;">
                            <i class="fas fa-times"></i> Cancel
                        </button>
                        <button type="submit" class="btn btn-primary" style="flex: 1;">
                            <i class="fas fa-save"></i> Save Changes
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <div class="footer-content">
            <div class="footer-logo">
                <i class="fas fa-cloud" style="color: #FFD700;"></i>
                <span style="color: #FFD700; font-weight: bold;">DriveSync</span>
            </div>
            
            <div class="footer-links">
                <a href="../../index.php">Home</a>
                <a href="files.php">My Files</a>
                <a href="upload.php">Upload</a>
                <a href="shared.php">Shared</a>
                <a href="profile.php">Profile</a>
                <a href="#">Help</a>
                <a href="#">Privacy</a>
                <a href="#">Terms</a>
            </div>
            
            <p class="copyright">
                &copy; 2024 DriveSync. All rights reserved. | Secure Cloud Storage Solution
            </p>
        </div>
    </footer>

    <script>
        // Mobile Menu Toggle
        const mobileMenuBtn = document.getElementById('mobileMenuBtn');
        const navLinks = document.getElementById('navLinks');
        
        mobileMenuBtn.addEventListener('click', function() {
            navLinks.classList.toggle('active');
            mobileMenuBtn.innerHTML = navLinks.classList.contains('active') 
                ? '<i class="fas fa-times"></i>' 
                : '<i class="fas fa-bars"></i>';
        });

        // Close mobile menu when clicking outside
        document.addEventListener('click', function(event) {
            if (!mobileMenuBtn.contains(event.target) && !navLinks.contains(event.target)) {
                navLinks.classList.remove('active');
                mobileMenuBtn.innerHTML = '<i class="fas fa-bars"></i>';
            }
        });

        // Profile Picture Modal
        function openProfilePicModal() {
            document.getElementById('profilePicModal').style.display = 'flex';
        }
        
        function closeProfilePicModal() {
            document.getElementById('profilePicModal').style.display = 'none';
        }
        
        // Close modal when clicking outside
        document.getElementById('profilePicModal').addEventListener('click', function(event) {
            if (event.target === this) {
                closeProfilePicModal();
            }
        });

        // Profile Picture Preview
        function previewProfileImage(event) {
            const input = event.target;
            const preview = document.getElementById('profile_preview');
            
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    preview.src = e.target.result;
                }
                
                reader.readAsDataURL(input.files[0]);
            }
        }

        // Update storage bar color based on usage
        document.addEventListener('DOMContentLoaded', function() {
            const storageFill = document.querySelector('.storage-fill');
            const percentage = <?php echo $storage_percentage; ?>;
            
            if (storageFill) {
                if (percentage > 90) {
                    storageFill.style.background = 'linear-gradient(90deg, #FF5252, #FF8A80)';
                } else if (percentage > 70) {
                    storageFill.style.background = 'linear-gradient(90deg, #FFA500, #FFD700)';
                } else {
                    storageFill.style.background = 'linear-gradient(90deg, #FFD700, #4CAF50)';
                }
            }
            
            // Auto-hide alerts after 5 seconds
            setTimeout(function() {
                const alerts = document.querySelectorAll('.alert');
                alerts.forEach(alert => {
                    alert.style.opacity = '0';
                    alert.style.transform = 'translateY(-10px)';
                    setTimeout(() => alert.remove(), 300);
                });
            }, 5000);
        });

        // Form validation
        document.querySelector('form').addEventListener('submit', function(event) {
            const firstName = document.getElementById('first_name');
            const lastName = document.getElementById('last_name');
            
            if (!firstName.value.trim() || !lastName.value.trim()) {
                event.preventDefault();
                alert('Please fill in all required fields.');
                return false;
            }
        });
    </script>
</body>
</html>