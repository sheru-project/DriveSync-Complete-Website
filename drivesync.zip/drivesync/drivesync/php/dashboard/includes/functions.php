<?php
// Check if user is logged in
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// Redirect if not logged in
function requireLogin() {
    if (!isLoggedIn()) {
        header("Location: ../auth/login.php");
        exit();
    }
}

// Redirect if already logged in (for login/signup pages)
function requireGuest() {
    if (isLoggedIn()) {
        header("Location: ../dashboard/files.php");
        exit();
    }
}

// Get user ID
function getUserId() {
    return $_SESSION['user_id'] ?? null;
}

// Get user data
function getUserData($conn) {
    if (!isLoggedIn()) return null;
    
    $user_id = getUserId();
    $sql = "SELECT * FROM users WHERE id = '$user_id'";
    $result = mysqli_query($conn, $sql);
    
    return mysqli_fetch_assoc($result);
}
?>