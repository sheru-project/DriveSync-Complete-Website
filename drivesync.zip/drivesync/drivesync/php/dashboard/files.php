<?php
// Start session
require_once '../config/session.php';
require_once '../config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Search functionality
$search = '';
if (isset($_GET['search'])) {
    $search = mysqli_real_escape_string($conn, $_GET['search']);
    $sql = "SELECT * FROM files WHERE user_id = '$user_id' 
            AND filename LIKE '%$search%' 
            ORDER BY upload_date DESC";
} else {
    $sql = "SELECT * FROM files WHERE user_id = '$user_id' ORDER BY upload_date DESC";
}

$result = mysqli_query($conn, $sql);

// Delete file
if (isset($_GET['delete'])) {
    $file_id = mysqli_real_escape_string($conn, $_GET['delete']);
    
    // Get file path
    $file_sql = "SELECT * FROM files WHERE id = '$file_id' AND user_id = '$user_id'";
    $file_result = mysqli_query($conn, $file_sql);
    
    if (mysqli_num_rows($file_result) == 1) {
        $file = mysqli_fetch_assoc($file_result);
        
        // Delete file from server
        if (file_exists($file['filepath'])) {
            unlink($file['filepath']);
        }
        
        // Delete from database
        $delete_sql = "DELETE FROM files WHERE id = '$file_id' AND user_id = '$user_id'";
        if (mysqli_query($conn, $delete_sql)) {
            $_SESSION['message'] = "File deleted successfully!";
            header("Location: files.php");
            exit();
        }
    }
}

// Check for success/error messages
$message = isset($_SESSION['message']) ? $_SESSION['message'] : '';
$error = isset($_SESSION['error']) ? $_SESSION['error'] : '';

// Clear messages after displaying
unset($_SESSION['message']);
unset($_SESSION['error']);

// Helper functions
function getFileIcon($filetype) {
    if (strpos($filetype, 'image') !== false) return 'fas fa-file-image';
    if (strpos($filetype, 'video') !== false) return 'fas fa-file-video';
    if (strpos($filetype, 'audio') !== false) return 'fas fa-file-audio';
    if (strpos($filetype, 'pdf') !== false) return 'fas fa-file-pdf';
    if (strpos($filetype, 'word') !== false || strpos($filetype, 'doc') !== false) return 'fas fa-file-word';
    if (strpos($filetype, 'excel') !== false || strpos($filetype, 'sheet') !== false) return 'fas fa-file-excel';
    if (strpos($filetype, 'powerpoint') !== false || strpos($filetype, 'presentation') !== false) return 'fas fa-file-powerpoint';
    if (strpos($filetype, 'zip') !== false || strpos($filetype, 'compressed') !== false) return 'fas fa-file-archive';
    if (strpos($filetype, 'text') !== false || strpos($filetype, 'txt') !== false) return 'fas fa-file-alt';
    return 'fas fa-file';
}

function formatFileSize($bytes) {
    if ($bytes == 0) return '0 B';
    
    $units = ['B', 'KB', 'MB', 'GB'];
    $i = 0;
    while ($bytes >= 1024 && $i < 3) {
        $bytes /= 1024;
        $i++;
    }
    return round($bytes, 2) . ' ' . $units[$i];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Files - DriveSync</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* ===== GLOBAL STYLES ===== */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #000000;
            color: #FFFFFF;
            line-height: 1.6;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* ===== NAVBAR ===== */
        .navbar {
            background-color: #111111;
            padding: 1rem 0;
            border-bottom: 2px solid #FFD700;
            position: sticky;
            top: 0;
            z-index: 1000;
            backdrop-filter: blur(10px);
        }

        .nav-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.5rem;
            font-weight: bold;
            text-decoration: none;
        }

        .logo i {
            color: #FFD700;
            font-size: 1.8rem;
        }

        .logo-text {
            background: linear-gradient(45deg, #FFD700, #FFA500);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }

        .nav-links {
            display: flex;
            gap: 1.5rem;
            align-items: center;
        }

        .nav-link {
            color: #FFFFFF;
            text-decoration: none;
            font-weight: 500;
            padding: 8px 15px;
            border-radius: 5px;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .nav-link:hover {
            color: #FFD700;
            background-color: rgba(255, 215, 0, 0.1);
        }

        .nav-link.active {
            color: #FFD700;
            background-color: rgba(255, 215, 0, 0.15);
        }

        .user-dropdown {
            position: relative;
        }

        .user-btn {
            display: flex;
            align-items: center;
            gap: 10px;
            background: none;
            border: none;
            color: #FFFFFF;
            cursor: pointer;
            padding: 8px 15px;
            border-radius: 5px;
            transition: all 0.3s ease;
        }

        .user-btn:hover {
            background-color: rgba(255, 215, 0, 0.1);
            color: #FFD700;
        }

        .user-avatar {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            background-color: #FFD700;
            color: #000000;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 1rem;
        }

        .dropdown-menu {
            position: absolute;
            top: 100%;
            right: 0;
            background-color: #111111;
            border: 1px solid #333333;
            border-radius: 8px;
            padding: 10px 0;
            min-width: 200px;
            display: none;
            z-index: 1000;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        }

        .user-dropdown:hover .dropdown-menu {
            display: block;
        }

        .dropdown-item {
            display: block;
            padding: 10px 20px;
            color: #CCCCCC;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .dropdown-item:hover {
            background-color: rgba(255, 215, 0, 0.1);
            color: #FFD700;
        }

        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            color: #FFD700;
            font-size: 1.5rem;
            cursor: pointer;
        }

        /* ===== DASHBOARD LAYOUT ===== */
        .dashboard-wrapper {
            flex: 1;
            display: flex;
        }

        /* Sidebar */
        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, #111111 0%, #0A0A0A 100%);
            border-right: 1px solid #222222;
            padding: 2rem 1.5rem;
            position: sticky;
            top: 70px;
            height: calc(100vh - 70px);
            overflow-y: auto;
        }

        .sidebar-profile {
            text-align: center;
            margin-bottom: 2rem;
            padding-bottom: 1.5rem;
            border-bottom: 1px solid #222222;
        }

        .sidebar-profile-pic {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #FFD700;
            margin-bottom: 1rem;
        }

        .sidebar-profile h4 {
            color: #FFFFFF;
            margin-bottom: 5px;
        }

        .sidebar-profile p {
            color: #888888;
            font-size: 0.9rem;
        }

        .sidebar-menu {
            list-style: none;
            margin-bottom: 2rem;
        }

        .sidebar-menu li {
            margin-bottom: 8px;
        }

        .sidebar-menu a {
            display: flex;
            align-items: center;
            gap: 12px;
            color: #CCCCCC;
            text-decoration: none;
            padding: 12px 15px;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .sidebar-menu a:hover {
            background-color: rgba(255, 215, 0, 0.1);
            color: #FFD700;
            transform: translateX(5px);
        }

        .sidebar-menu a.active {
            background-color: rgba(255, 215, 0, 0.15);
            color: #FFD700;
            border-left: 3px solid #FFD700;
        }

        .storage-info {
            background-color: #0A0A0A;
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
            border: 1px solid #222222;
        }

        .storage-label {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
            font-size: 0.9rem;
        }

        .storage-bar {
            height: 6px;
            background-color: #222222;
            border-radius: 3px;
            overflow: hidden;
        }

        .storage-fill {
            height: 100%;
            background: linear-gradient(90deg, #FFD700, #FFA500);
            border-radius: 3px;
            width: 30%;
        }

        /* ===== MAIN CONTENT ===== */
        .main-content {
            flex: 1;
            padding: 2rem;
            background-color: #0A0A0A;
            overflow-y: auto;
        }

        .page-header {
            margin-bottom: 2rem;
            padding-bottom: 1.5rem;
            border-bottom: 1px solid #222222;
        }

        .page-header h1 {
            color: #FFD700;
            font-size: 2.2rem;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        /* Action Bar */
        .action-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            gap: 1.5rem;
        }

        .search-form {
            flex: 1;
            max-width: 500px;
        }

        .search-box {
            position: relative;
            display: flex;
        }

        .search-box input {
            flex: 1;
            padding: 12px 45px 12px 15px;
            background-color: #111111;
            border: 1px solid #333333;
            border-radius: 8px;
            color: #FFFFFF;
            font-size: 1rem;
        }

        .search-box input:focus {
            outline: none;
            border-color: #FFD700;
            box-shadow: 0 0 0 3px rgba(255, 215, 0, 0.1);
        }

        .search-btn {
            position: absolute;
            right: 0;
            top: 0;
            height: 100%;
            background: none;
            border: none;
            color: #FFD700;
            padding: 0 15px;
            cursor: pointer;
            font-size: 1.1rem;
        }

        /* Stats Cards */
        .stats-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2.5rem;
        }

        .stat-card {
            background: linear-gradient(135deg, #111111, #0A0A0A);
            padding: 1.8rem;
            border-radius: 12px;
            border: 1px solid #222222;
            text-align: center;
            transition: all 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            border-color: #FFD700;
            box-shadow: 0 10px 25px rgba(255, 215, 0, 0.1);
        }

        .stat-card h3 {
            color: #FFD700;
            font-size: 2.5rem;
            margin-bottom: 0.5rem;
            font-weight: bold;
        }

        .stat-card p {
            color: #AAAAAA;
            font-size: 0.95rem;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        /* Files Table */
        .files-table-container {
            background: #111111;
            border-radius: 12px;
            padding: 1.5rem;
            border: 1px solid #222222;
            overflow: hidden;
        }

        .files-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }

        .files-table thead {
            background-color: #0A0A0A;
        }

        .files-table th {
            padding: 15px;
            text-align: left;
            color: #FFD700;
            font-weight: 600;
            border-bottom: 2px solid #222222;
            font-size: 0.95rem;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .files-table td {
            padding: 15px;
            border-bottom: 1px solid #222222;
            color: #CCCCCC;
        }

        .files-table tr:hover {
            background-color: rgba(255, 215, 0, 0.03);
        }

        .files-table tr:last-child td {
            border-bottom: none;
        }

        .file-info {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .file-icon {
            color: #FFD700;
            font-size: 1.2rem;
            width: 24px;
        }

        /* Action Buttons */
        .action-buttons {
            display: flex;
            gap: 8px;
        }

        .btn-action {
            padding: 8px 12px;
            background-color: #222222;
            border: 1px solid #333333;
            border-radius: 5px;
            color: #FFFFFF;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s ease;
        }

        .btn-action:hover {
            background-color: #333333;
            transform: translateY(-2px);
        }

        .btn-download {
            color: #4CAF50;
            border-color: #4CAF50;
        }

        .btn-download:hover {
            background-color: rgba(76, 175, 80, 0.1);
        }

        .btn-share {
            color: #2196F3;
            border-color: #2196F3;
        }

        .btn-share:hover {
            background-color: rgba(33, 150, 243, 0.1);
        }

        .btn-delete {
            color: #FF5252;
            border-color: #FF5252;
        }

        .btn-delete:hover {
            background-color: rgba(255, 82, 82, 0.1);
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 4rem 2rem;
            color: #666666;
        }

        .empty-state i {
            font-size: 4rem;
            margin-bottom: 1.5rem;
            color: #333333;
        }

        .empty-state h3 {
            color: #888888;
            margin-bottom: 1rem;
            font-size: 1.5rem;
        }

        .empty-state p {
            color: #666666;
            margin-bottom: 2rem;
            max-width: 400px;
            margin-left: auto;
            margin-right: auto;
        }

        /* Alerts */
        .alert {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 2rem;
            border-left: 4px solid;
            display: flex;
            align-items: center;
            gap: 12px;
            animation: slideIn 0.3s ease;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .alert-success {
            background-color: rgba(76, 175, 80, 0.1);
            border-color: #4CAF50;
            color: #A5D6A7;
        }

        .alert-error {
            background-color: rgba(255, 82, 82, 0.1);
            border-color: #FF5252;
            color: #FF8A80;
        }

        /* ===== FOOTER ===== */
        footer {
            background-color: #050505;
            padding: 2rem;
            border-top: 1px solid #222222;
            margin-top: auto;
        }

        .footer-content {
            max-width: 1400px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 2rem;
        }

        .footer-logo {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .footer-links {
            display: flex;
            gap: 1.5rem;
            flex-wrap: wrap;
        }

        .footer-links a {
            color: #888888;
            text-decoration: none;
            transition: color 0.3s ease;
            font-size: 0.9rem;
        }

        .footer-links a:hover {
            color: #FFD700;
        }

        .copyright {
            color: #666666;
            font-size: 0.9rem;
            text-align: center;
            width: 100%;
            margin-top: 1rem;
        }

        /* ===== BUTTONS ===== */
        .btn-primary {
            background: linear-gradient(135deg, #FFD700 0%, #FFA500 100%);
            color: #000000;
            padding: 12px 25px;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: bold;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(255, 215, 0, 0.3);
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(255, 215, 0, 0.4);
        }

        /* ===== RESPONSIVE DESIGN ===== */
        @media (max-width: 1024px) {
            .nav-container, .footer-content {
                padding: 0 1.5rem;
            }
            
            .main-content {
                padding: 1.5rem;
            }
            
            .stats-cards {
                gap: 1rem;
            }
        }

        @media (max-width: 768px) {
            .mobile-menu-btn {
                display: block;
            }
            
            .nav-links {
                position: fixed;
                top: 70px;
                left: 0;
                right: 0;
                background-color: #111111;
                flex-direction: column;
                padding: 2rem;
                gap: 1rem;
                transform: translateY(-100%);
                opacity: 0;
                visibility: hidden;
                transition: all 0.3s ease;
                border-bottom: 2px solid #FFD700;
            }
            
            .nav-links.active {
                transform: translateY(0);
                opacity: 1;
                visibility: visible;
            }
            
            .dashboard-wrapper {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                height: auto;
                position: static;
                border-right: none;
                border-bottom: 1px solid #222222;
            }
            
            .sidebar-menu {
                display: flex;
                flex-wrap: wrap;
                gap: 0.5rem;
            }
            
            .sidebar-menu li {
                flex: 1;
                min-width: 120px;
            }
            
            .sidebar-menu a {
                justify-content: center;
                text-align: center;
            }
            
            .action-bar {
                flex-direction: column;
                align-items: stretch;
            }
            
            .search-form {
                max-width: 100%;
            }
            
            .files-table {
                display: block;
                overflow-x: auto;
            }
            
            .footer-content {
                flex-direction: column;
                text-align: center;
                gap: 1rem;
            }
        }

        @media (max-width: 480px) {
            .nav-container {
                padding: 0 1rem;
            }
            
            .main-content {
                padding: 1rem;
            }
            
            .page-header h1 {
                font-size: 1.8rem;
            }
            
            .stats-cards {
                grid-template-columns: 1fr;
            }
            
            .action-buttons {
                flex-direction: column;
                gap: 5px;
            }
            
            .btn-action {
                padding: 6px 10px;
                font-size: 0.9rem;
            }
        }

        /* ===== SCROLL BAR ===== */
        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: #111111;
        }

        ::-webkit-scrollbar-thumb {
            background: #FFD700;
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: #FFA500;
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar">
        <div class="nav-container">
            <a href="../../index.php" class="logo">
                <i class="fas fa-cloud"></i>
                <span class="logo-text">DriveSync</span>
            </a>
            
            <button class="mobile-menu-btn" id="mobileMenuBtn">
                <i class="fas fa-bars"></i>
            </button>
            
            <div class="nav-links" id="navLinks">
                <a href="../../index.php" class="nav-link">
                    <i class="fas fa-home"></i> Home
                </a>
                <a href="files.php" class="nav-link active">
                    <i class="fas fa-folder"></i> My Files
                </a>
                <a href="upload.php" class="nav-link">
                    <i class="fas fa-upload"></i> Upload
                </a>
                <a href="shared.php" class="nav-link">
                    <i class="fas fa-share-alt"></i> Shared
                </a>
                
                <!-- User Dropdown -->
                <div class="user-dropdown">
                    <button class="user-btn">
                        <div class="user-avatar">
                            <?php 
                            $first_letter = isset($_SESSION['user_name']) ? strtoupper(substr($_SESSION['user_name'], 0, 1)) : 'U';
                            echo $first_letter;
                            ?>
                        </div>
                        <span><?php echo $_SESSION['user_name'] ?? 'User'; ?></span>
                        <i class="fas fa-chevron-down"></i>
                    </button>
                    
                    <div class="dropdown-menu">
                        <a href="profile.php" class="dropdown-item">
                            <i class="fas fa-user"></i> My Profile
                        </a>
                        <a href="change-password.php" class="dropdown-item">
                            <i class="fas fa-key"></i> Change Password
                        </a>
                        <div class="dropdown-divider"></div>
                        <a href="../auth/logout.php" class="dropdown-item" onclick="return confirm('Are you sure you want to logout?')">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <!-- Dashboard Wrapper -->
    <div class="dashboard-wrapper">
        <!-- Sidebar -->
        <aside class="sidebar">
            <!-- User Profile -->
            <div class="sidebar-profile">
                <div class="user-avatar" style="width: 80px; height: 80px; margin: 0 auto 15px; background: #FFD700; color: #000; display: flex; align-items: center; justify-content: center; font-size: 2rem; font-weight: bold; border-radius: 50%;">
                    <?php 
                    $first_letter = isset($_SESSION['user_name']) ? strtoupper(substr($_SESSION['user_name'], 0, 1)) : 'U';
                    echo $first_letter;
                    ?>
                </div>
                <h4><?php echo $_SESSION['user_name'] ?? 'User'; ?></h4>
                <p><?php echo $_SESSION['user_email'] ?? 'user@example.com'; ?></p>
            </div>
            
            <!-- Storage Info -->
            <div class="storage-info">
                <div class="storage-label">
                    <span>Storage Used</span>
                    <span>1.2 GB / 100 GB</span>
                </div>
                <div class="storage-bar">
                    <div class="storage-fill"></div>
                </div>
            </div>
            
            <!-- Navigation Menu -->
            <ul class="sidebar-menu">
                <li>
                    <a href="files.php" class="active">
                        <i class="fas fa-folder"></i> My Files
                    </a>
                </li>
                <li>
                    <a href="upload.php">
                        <i class="fas fa-upload"></i> Upload Files
                    </a>
                </li>
                <li>
                    <a href="shared.php">
                        <i class="fas fa-share-alt"></i> Shared Files
                    </a>
                </li>
                <li>
                    <a href="profile.php">
                        <i class="fas fa-user"></i> My Profile
                    </a>
                </li>
                <li>
                    <a href="change-password.php">
                        <i class="fas fa-key"></i> Change Password
                    </a>
                </li>
                <li>
                    <a href="../auth/logout.php" onclick="return confirm('Are you sure you want to logout?')">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </li>
            </ul>
            
            <!-- Quick Stats -->
            <div class="storage-info">
                <h4 style="color: #FFD700; margin-bottom: 15px; font-size: 0.9rem;">Quick Stats</h4>
                <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                    <span style="color: #CCCCCC; font-size: 0.9rem;">Total Files</span>
                    <span style="color: #FFD700; font-weight: bold;"><?php echo mysqli_num_rows($result); ?></span>
                </div>
                <div style="display: flex; justify-content: space-between;">
                    <span style="color: #CCCCCC; font-size: 0.9rem;">Storage Used</span>
                    <span style="color: #FFD700; font-weight: bold;">
                        <?php 
                        $size_sql = "SELECT SUM(filesize) as total_size FROM files WHERE user_id = '$user_id'";
                        $size_result = mysqli_query($conn, $size_sql);
                        $size_row = mysqli_fetch_assoc($size_result);
                        echo formatFileSize($size_row['total_size'] ?: 0);
                        ?>
                    </span>
                </div>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Page Header -->
            <div class="page-header">
                <h1>
                    <i class="fas fa-folder"></i> My Files
                </h1>
                
                <?php if ($message): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i>
                        <span><?php echo htmlspecialchars($message); ?></span>
                    </div>
                <?php endif; ?>
                
                <?php if ($error): ?>
                    <div class="alert alert-error">
                        <i class="fas fa-exclamation-circle"></i>
                        <span><?php echo htmlspecialchars($error); ?></span>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- Action Bar -->
            <div class="action-bar">
                <form method="GET" class="search-form">
                    <div class="search-box">
                        <input type="text" name="search" 
                               placeholder="Search files by name..."
                               value="<?php echo htmlspecialchars($search); ?>">
                        <button type="submit" class="search-btn">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                </form>
                
                <a href="upload.php" class="btn-primary">
                    <i class="fas fa-upload"></i> Upload New File
                </a>
            </div>
            
            <!-- File Stats -->
            <div class="stats-cards">
                <div class="stat-card">
                    <h3><?php echo mysqli_num_rows($result); ?></h3>
                    <p>Total Files</p>
                </div>
                <div class="stat-card">
                    <h3>
                        <?php 
                        $size_sql = "SELECT SUM(filesize) as total_size FROM files WHERE user_id = '$user_id'";
                        $size_result = mysqli_query($conn, $size_sql);
                        $size_row = mysqli_fetch_assoc($size_result);
                        echo formatFileSize($size_row['total_size'] ?: 0);
                        ?>
                    </h3>
                    <p>Storage Used</p>
                </div>
                <div class="stat-card">
                    <h3>
                        <?php
                        $recent_sql = "SELECT COUNT(*) as recent_count FROM files 
                                      WHERE user_id = '$user_id' 
                                      AND upload_date >= DATE_SUB(NOW(), INTERVAL 7 DAY)";
                        $recent_result = mysqli_query($conn, $recent_sql);
                        $recent_row = mysqli_fetch_assoc($recent_result);
                        echo $recent_row['recent_count'];
                        ?>
                    </h3>
                    <p>Last 7 Days</p>
                </div>
            </div>
            
            <!-- Files Table -->
            <div class="files-table-container">
                <?php if (mysqli_num_rows($result) > 0): ?>
                <table class="files-table">
                    <thead>
                        <tr>
                            <th>File Name</th>
                            <th>Type</th>
                            <th>Size</th>
                            <th>Upload Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($result)): 
                            $icon = getFileIcon($row['filetype']);
                            $file_extension = strtoupper(pathinfo($row['filename'], PATHINFO_EXTENSION));
                        ?>
                        <tr>
                            <td>
                                <div class="file-info">
                                    <i class="<?php echo $icon; ?> file-icon"></i>
                                    <span title="<?php echo htmlspecialchars($row['filename']); ?>">
                                        <?php 
                                        $filename = htmlspecialchars($row['filename']);
                                        echo strlen($filename) > 30 ? substr($filename, 0, 30) . '...' : $filename;
                                        ?>
                                    </span>
                                </div>
                            </td>
                            <td><?php echo $file_extension ?: 'Unknown'; ?></td>
                            <td><?php echo formatFileSize($row['filesize']); ?></td>
                            <td><?php echo date('d M Y, h:i A', strtotime($row['upload_date'])); ?></td>
                            <td>
                                <div class="action-buttons">
                                    <a href="download.php?id=<?php echo $row['id']; ?>" 
                                       class="btn-action btn-download" title="Download">
                                        <i class="fas fa-download"></i>
                                    </a>
                                    <a href="share.php?id=<?php echo $row['id']; ?>" 
                                       class="btn-action btn-share" title="Share">
                                        <i class="fas fa-share-alt"></i>
                                    </a>
                                    <a href="?delete=<?php echo $row['id']; ?>" 
                                       class="btn-action btn-delete" 
                                       title="Delete"
                                       onclick="return confirm('Are you sure you want to delete <?php echo htmlspecialchars(addslashes($row['filename'])); ?>?')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
                <?php else: ?>
                <div class="empty-state">
                    <i class="fas fa-folder-open"></i>
                    <h3>No Files Found</h3>
                    <p>You haven't uploaded any files yet. Start by uploading your first file.</p>
                    <a href="upload.php" class="btn-primary">
                        <i class="fas fa-upload"></i> Upload Your First File
                    </a>
                </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <!-- Footer -->
    <footer>
        <div class="footer-content">
            <div class="footer-logo">
                <i class="fas fa-cloud" style="color: #FFD700;"></i>
                <span style="color: #FFD700; font-weight: bold;">DriveSync</span>
            </div>
            
            <div class="footer-links">
                <a href="../../index.php">Home</a>
                <a href="files.php">My Files</a>
                <a href="upload.php">Upload</a>
                <a href="profile.php">Profile</a>
                <a href="#">Help</a>
                <a href="#">Privacy</a>
                <a href="#">Terms</a>
            </div>
            
            <p class="copyright">
                &copy; 2024 DriveSync. All rights reserved. | Secure Cloud Storage Solution
            </p>
        </div>
    </footer>

    <script>
        // Mobile Menu Toggle
        const mobileMenuBtn = document.getElementById('mobileMenuBtn');
        const navLinks = document.getElementById('navLinks');
        
        mobileMenuBtn.addEventListener('click', function() {
            navLinks.classList.toggle('active');
            mobileMenuBtn.innerHTML = navLinks.classList.contains('active') 
                ? '<i class="fas fa-times"></i>' 
                : '<i class="fas fa-bars"></i>';
        });

        // Close mobile menu when clicking outside
        document.addEventListener('click', function(event) {
            if (!mobileMenuBtn.contains(event.target) && !navLinks.contains(event.target)) {
                navLinks.classList.remove('active');
                mobileMenuBtn.innerHTML = '<i class="fas fa-bars"></i>';
            }
        });

        // File search functionality
        document.addEventListener('DOMContentLoaded', function() {
            const searchInput = document.querySelector('input[name="search"]');
            const searchForm = document.querySelector('.search-form');
            
            // Auto-submit when search input is cleared
            searchInput.addEventListener('input', function() {
                if (this.value === '' && window.location.search.includes('search=')) {
                    searchForm.submit();
                }
            });
            
            // Focus search input if there's a search term
            if (searchInput.value) {
                searchInput.focus();
                searchInput.setSelectionRange(searchInput.value.length, searchInput.value.length);
            }
            
            // Keyboard shortcut for search (Ctrl + F)
            document.addEventListener('keydown', function(e) {
                if ((e.ctrlKey || e.metaKey) && e.key === 'f') {
                    e.preventDefault();
                    searchInput.focus();
                }
            });
        });

        // Update storage bar based on actual usage
        document.addEventListener('DOMContentLoaded', function() {
            const storageFill = document.querySelector('.storage-fill');
            const usedSpan = document.querySelector('.storage-info .storage-label span:last-child');
            
            // Extract used storage from text (e.g., "1.2 GB / 100 GB")
            if (usedSpan && storageFill) {
                const text = usedSpan.textContent;
                const match = text.match(/(\d+\.?\d*)\s*GB\s*\/\s*100\s*GB/);

                if (match) {
                    const usedGB = parseFloat(match[1]);
                    const percentage = (usedGB / 100) * 100;
                    storageFill.style.width = Math.min(percentage, 100) + '%';
                    
                    // Change color based on usage
                    if (percentage > 90) {
                        storageFill.style.background = 'linear-gradient(90deg, #FF5252, #FF8A80)';
                    } else if (percentage > 70) {
                        storageFill.style.background = 'linear-gradient(90deg, #FFA500, #FFD700)';
                    }
                }
            }
        });
    </script>
</body>
</html>