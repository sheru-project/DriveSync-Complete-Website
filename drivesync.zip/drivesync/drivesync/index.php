<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DriveSync - Your Cloud Storage</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* ===== GLOBAL STYLES ===== */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #000000;
            color: #FFFFFF;
            line-height: 1.6;
            overflow-x: hidden;
        }

        /* ===== NAVBAR - FIXED ===== */
        .navbar {
            background-color: #111111;
            padding: 1rem 0;
            border-bottom: 2px solid #FFD700;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            z-index: 1000;
            backdrop-filter: blur(10px);
            box-shadow: 0 2px 20px rgba(0, 0, 0, 0.3);
        }

        .nav-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.8rem;
            font-weight: bold;
            cursor: pointer;
        }

        .logo i {
            color: #FFD700;
            font-size: 2rem;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }

        .logo-text {
            background: linear-gradient(45deg, #FFD700, #FFA500);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            text-shadow: 0 2px 10px rgba(255, 215, 0, 0.2);
        }

        .nav-links {
            display: flex;
            gap: 2rem;
            align-items: center;
        }

        .nav-link {
            color: #FFFFFF;
            text-decoration: none;
            font-weight: 500;
            font-size: 1rem;
            padding: 8px 15px;
            border-radius: 5px;
            transition: all 0.3s ease;
            position: relative;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .nav-link:hover {
            color: #FFD700;
            background-color: rgba(255, 215, 0, 0.1);
        }

        .nav-link.active {
            color: #FFD700;
            background-color: rgba(255, 215, 0, 0.15);
        }

        .nav-link.active::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 50%;
            transform: translateX(-50%);
            width: 30px;
            height: 3px;
            background-color: #FFD700;
            border-radius: 2px;
        }

        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            color: #FFD700;
            font-size: 1.5rem;
            cursor: pointer;
        }

        /* ===== HERO SECTION ===== */
        .hero {
            background: linear-gradient(rgba(0, 0, 0, 0.9), rgba(0, 0, 0, 0.95)),
                        url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="none"><defs><pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse"><path d="M 20 0 L 0 0 0 20" fill="none" stroke="%23FFD700" stroke-width="0.3" opacity="0.1"/></pattern></defs><rect width="100" height="100" fill="url(%23grid)"/></svg>');
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            padding: 6rem 2rem 2rem;
            position: relative;
            overflow: hidden;
        }

        .hero::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: radial-gradient(circle at 20% 50%, rgba(255, 215, 0, 0.05) 0%, transparent 50%),
                        radial-gradient(circle at 80% 20%, rgba(255, 215, 0, 0.03) 0%, transparent 50%);
            pointer-events: none;
        }

        .hero-content {
            max-width: 800px;
            position: relative;
            z-index: 2;
            animation: fadeInUp 1s ease-out;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .hero h1 {
            font-size: 3.5rem;
            margin-bottom: 1.5rem;
            background: linear-gradient(to right, #FFFFFF, #FFD700);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            line-height: 1.2;
        }

        .hero p {
            font-size: 1.3rem;
            color: #CCCCCC;
            margin-bottom: 2.5rem;
            line-height: 1.6;
            max-width: 600px;
            margin: 0 auto 2.5rem;
        }

        /* ===== BUTTONS ===== */
        .btn-primary {
            background: linear-gradient(135deg, #FFD700 0%, #FFA500 100%);
            color: #000000;
            padding: 15px 40px;
            border: none;
            border-radius: 8px;
            font-size: 1.1rem;
            font-weight: bold;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(255, 215, 0, 0.3);
            position: relative;
            overflow: hidden;
        }

        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(255, 215, 0, 0.4);
        }

        .btn-primary:active {
            transform: translateY(-1px);
        }

        .btn-secondary {
            background: transparent;
            border: 2px solid #FFD700;
            color: #FFD700;
            padding: 13px 30px;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: bold;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            transition: all 0.3s ease;
        }

        .btn-secondary:hover {
            background-color: #FFD700;
            color: #000000;
        }

        .hero-buttons {
            display: flex;
            gap: 1rem;
            justify-content: center;
            margin-bottom: 3rem;
        }

        /* ===== STATS ===== */
        .hero-stats {
            display: flex;
            justify-content: center;
            gap: 3rem;
            margin-top: 3rem;
            flex-wrap: wrap;
        }

        .stat {
            text-align: center;
            padding: 1.5rem;
            background: rgba(255, 215, 0, 0.05);
            border-radius: 10px;
            border: 1px solid rgba(255, 215, 0, 0.1);
            min-width: 120px;
            transition: transform 0.3s ease;
        }

        .stat:hover {
            transform: translateY(-5px);
            border-color: #FFD700;
        }

        .stat-number {
            display: block;
            font-size: 2.5rem;
            font-weight: bold;
            color: #FFD700;
            margin-bottom: 0.5rem;
        }

        .stat-label {
            color: #AAAAAA;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        /* ===== FEATURES SECTION ===== */
        .features {
            background-color: #0A0A0A;
            padding: 6rem 2rem;
        }

        .features h2 {
            text-align: center;
            font-size: 2.5rem;
            margin-bottom: 4rem;
            color: #FFD700;
            position: relative;
        }

        .features h2::after {
            content: '';
            position: absolute;
            bottom: -15px;
            left: 50%;
            transform: translateX(-50%);
            width: 100px;
            height: 3px;
            background: linear-gradient(to right, transparent, #FFD700, transparent);
        }

        .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2.5rem;
            max-width: 1200px;
            margin: 0 auto;
        }

        .feature-card {
            background: linear-gradient(145deg, #111111, #0A0A0A);
            padding: 2.5rem 2rem;
            border-radius: 15px;
            text-align: center;
            border: 1px solid #222222;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .feature-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: linear-gradient(to right, transparent, #FFD700, transparent);
            transform: translateX(-100%);
            transition: transform 0.5s ease;
        }

        .feature-card:hover {
            transform: translateY(-10px);
            border-color: #FFD700;
            box-shadow: 0 15px 30px rgba(255, 215, 0, 0.1);
        }

        .feature-card:hover::before {
            transform: translateX(0);
        }

        .feature-card i {
            font-size: 3.5rem;
            color: #FFD700;
            margin-bottom: 1.5rem;
            transition: transform 0.3s ease;
        }

        .feature-card:hover i {
            transform: scale(1.1) rotate(5deg);
        }

        .feature-card h3 {
            color: #FFFFFF;
            margin-bottom: 1rem;
            font-size: 1.5rem;
        }

        .feature-card p {
            color: #AAAAAA;
            line-height: 1.6;
        }

        /* ===== CTA SECTION ===== */
        .cta-section {
            background: linear-gradient(135deg, #0A0A0A 0%, #111111 100%);
            padding: 6rem 2rem;
            text-align: center;
            border-top: 1px solid #222222;
            border-bottom: 1px solid #222222;
            position: relative;
            overflow: hidden;
        }

        .cta-section::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            right: -50%;
            bottom: -50%;
            background: radial-gradient(circle, rgba(255,215,0,0.05) 0%, transparent 70%);
            animation: rotate 20s linear infinite;
        }

        @keyframes rotate {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }

        .cta-content {
            position: relative;
            z-index: 2;
        }

        .cta-content h2 {
            color: #FFFFFF;
            font-size: 2.5rem;
            margin-bottom: 1.5rem;
        }

        .cta-content p {
            color: #CCCCCC;
            font-size: 1.2rem;
            margin-bottom: 2.5rem;
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
        }

        .btn-large {
            padding: 18px 50px;
            font-size: 1.2rem;
        }

        /* ===== FOOTER ===== */
        footer {
            background-color: #050505;
            padding: 3rem 2rem;
            border-top: 1px solid #222222;
        }

        .footer-content {
            max-width: 1200px;
            margin: 0 auto;
            text-align: center;
        }

        .footer-logo {
            margin-bottom: 2rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        .footer-links {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 2rem;
            margin-bottom: 2rem;
        }

        .footer-links a {
            color: #888888;
            text-decoration: none;
            transition: color 0.3s ease;
            font-size: 0.95rem;
        }

        .footer-links a:hover {
            color: #FFD700;
        }

        footer p {
            color: #666666;
            font-size: 0.9rem;
        }

        /* ===== RESPONSIVE DESIGN ===== */
        @media (max-width: 1024px) {
            .nav-container {
                padding: 0 1.5rem;
            }
            
            .hero h1 {
                font-size: 3rem;
            }
            
            .features-grid {
                gap: 2rem;
            }
        }

        @media (max-width: 768px) {
            .mobile-menu-btn {
                display: block;
            }
            
            .nav-links {
                position: fixed;
                top: 70px;
                left: 0;
                right: 0;
                background-color: #111111;
                flex-direction: column;
                padding: 2rem;
                gap: 1rem;
                transform: translateY(-100%);
                opacity: 0;
                visibility: hidden;
                transition: all 0.3s ease;
                border-bottom: 2px solid #FFD700;
                box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            }
            
            .nav-links.active {
                transform: translateY(0);
                opacity: 1;
                visibility: visible;
            }
            
            .nav-link {
                padding: 12px 20px;
                justify-content: center;
            }
            
            .hero {
                padding: 5rem 1.5rem 1.5rem;
            }
            
            .hero h1 {
                font-size: 2.5rem;
            }
            
            .hero p {
                font-size: 1.1rem;
            }
            
            .hero-buttons {
                flex-direction: column;
                align-items: center;
            }
            
            .hero-stats {
                gap: 1.5rem;
            }
            
            .stat {
                min-width: 100px;
                padding: 1rem;
            }
            
            .stat-number {
                font-size: 2rem;
            }
            
            .features-grid {
                grid-template-columns: 1fr;
                gap: 2rem;
            }
            
            .feature-card {
                padding: 2rem 1.5rem;
            }
            
            .cta-content h2 {
                font-size: 2rem;
            }
            
            .footer-links {
                flex-direction: column;
                gap: 1rem;
            }
        }

        @media (max-width: 480px) {
            .nav-container {
                padding: 0 1rem;
            }
            
            .logo {
                font-size: 1.5rem;
            }
            
            .logo i {
                font-size: 1.8rem;
            }
            
            .hero h1 {
                font-size: 2rem;
            }
            
            .hero p {
                font-size: 1rem;
            }
            
            .btn-primary, .btn-secondary {
                padding: 12px 25px;
                font-size: 0.95rem;
                width: 100%;
                justify-content: center;
            }
            
            .features h2 {
                font-size: 2rem;
            }
            
            .cta-content h2 {
                font-size: 1.8rem;
            }
        }

        /* ===== SCROLL BAR ===== */
        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: #111111;
        }

        ::-webkit-scrollbar-thumb {
            background: #FFD700;
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: #FFA500;
        }

        /* ===== FLOATING PARTICLES ===== */
        .particles {
            position: absolute;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            pointer-events: none;
            z-index: 1;
        }

        .particle {
            position: absolute;
            width: 2px;
            height: 2px;
            background-color: #FFD700;
            border-radius: 50%;
            opacity: 0.3;
            animation: float 15s infinite linear;
        }

        @keyframes float {
            0% {
                transform: translateY(100vh) translateX(0);
                opacity: 0;
            }
            10% {
                opacity: 0.3;
            }
            90% {
                opacity: 0.3;
            }
            100% {
                transform: translateY(-100px) translateX(100px);
                opacity: 0;
            }
        }

        /* ===== LOADING ANIMATION ===== */
        .loading {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: #000000;
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 9999;
            transition: opacity 0.5s ease;
        }

        .loader {
            width: 50px;
            height: 50px;
            border: 3px solid #111111;
            border-top: 3px solid #FFD700;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
    </style>
</head>
<body>
    <!-- Loading Screen -->
    <div class="loading" id="loading">
        <div class="loader"></div>
    </div>

    <!-- Navigation -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="logo" onclick="window.location.href='index.php'">
                <i class="fas fa-cloud"></i>
                <span class="logo-text">DriveSync</span>
            </div>
            
            <button class="mobile-menu-btn" id="mobileMenuBtn">
                <i class="fas fa-bars"></i>
            </button>
            
            <div class="nav-links" id="navLinks">
                <a href="index.php" class="nav-link active">
                    <i class="fas fa-home"></i> Home
                </a>
                <a href="#features" class="nav-link">
                    <i class="fas fa-star"></i> Features
                </a>
                <?php if(isset($_SESSION['user_id'])): ?>
                    <a href="php/dashboard/files.php" class="nav-link">
                        <i class="fas fa-folder"></i> Dashboard
                    </a>
                    <a href="php/dashboard/profile.php" class="nav-link">
                        <i class="fas fa-user"></i> Profile
                    </a>
                    <a href="php/auth/logout.php" class="nav-link">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                <?php else: ?>
                    <a href="php/auth/login.php" class="nav-link">
                        <i class="fas fa-sign-in-alt"></i> Login
                    </a>
                    <a href="php/auth/signup.php" class="nav-link">
                        <i class="fas fa-user-plus"></i> Sign Up
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero">
        <div class="particles" id="particles"></div>
        
        <div class="hero-content">
            <h1>Secure Cloud Storage, Anytime, Anywhere</h1>
            <p>Store, share, and access your files with military-grade security. Professional cloud storage solution for individuals and businesses.</p>
            
            <div class="hero-buttons">
                <a href="php/auth/signup.php" class="btn-primary">
                    <i class="fas fa-rocket"></i> Start Free Trial
                </a>
                <a href="#features" class="btn-secondary">
                    <i class="fas fa-play-circle"></i> Learn More
                </a>
            </div>
            
            <div class="hero-stats">
                <div class="stat">
                    <span class="stat-number">100GB</span>
                    <span class="stat-label">Free Storage</span>
                </div>
                <div class="stat">
                    <span class="stat-number">256-bit</span>
                    <span class="stat-label">Encryption</span>
                </div>
                <div class="stat">
                    <span class="stat-number">99.9%</span>
                    <span class="stat-label">Uptime</span>
                </div>
                <div class="stat">
                    <span class="stat-number">24/7</span>
                    <span class="stat-label">Support</span>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section id="features" class="features">
        <h2>Premium Features</h2>
        <div class="features-grid">
            <div class="feature-card">
                <i class="fas fa-cloud-upload-alt"></i>
                <h3>Smart Upload</h3>
                <p>Drag & drop interface with automatic file organization and preview</p>
            </div>
            <div class="feature-card">
                <i class="fas fa-shield-alt"></i>
                <h3>Military Security</h3>
                <p>End-to-end encryption with two-factor authentication and audit logs</p>
            </div>
            <div class="feature-card">
                <i class="fas fa-sync-alt"></i>
                <h3>Real-time Sync</h3>
                <p>Automatic synchronization across all your devices instantly</p>
            </div>
            <div class="feature-card">
                <i class="fas fa-users"></i>
                <h3>Team Collaboration</h3>
                <p>Share files and folders with team members and control permissions</p>
            </div>
            <div class="feature-card">
                <i class="fas fa-history"></i>
                <h3>Version History</h3>
                <p>Track changes and restore previous versions of any file</p>
            </div>
            <div class="feature-card">
                <i class="fas fa-chart-line"></i>
                <h3>Analytics Dashboard</h3>
                <p>Detailed insights into storage usage and file access patterns</p>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="cta-section">
        <div class="cta-content">
            <h2>Ready to Transform Your Digital Storage?</h2>
            <p>Join over 50,000 professionals who trust DriveSync with their important files.</p>
            <a href="php/auth/signup.php" class="btn-primary btn-large">
                <i class="fas fa-cloud-upload-alt"></i> Create Free Account
            </a>
            <p style="margin-top: 1rem; color: #888; font-size: 0.9rem;">No credit card required. 30-day free trial.</p>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <div class="footer-content">
            <div class="footer-logo">
                <i class="fas fa-cloud" style="color: #FFD700;"></i>
                <span class="logo-text">DriveSync</span>
            </div>
            
            <div class="footer-links">
                <a href="index.php">Home</a>
                <a href="#features">Features</a>
                <a href="php/auth/login.php">Login</a>
                <a href="php/auth/signup.php">Sign Up</a>
                <a href="#">Privacy Policy</a>
                <a href="#">Terms of Service</a>
                <a href="#">Support</a>
            </div>
            
            <p>&copy; 2024 DriveSync. All rights reserved. | Professional Cloud Storage Solution</p>
        </div>
    </footer>

    <script>
        // Page Loading
        window.addEventListener('load', function() {
            setTimeout(function() {
                document.getElementById('loading').style.opacity = '0';
                setTimeout(function() {
                    document.getElementById('loading').style.display = 'none';
                }, 500);
            }, 500);
        });

        // Mobile Menu Toggle
        const mobileMenuBtn = document.getElementById('mobileMenuBtn');
        const navLinks = document.getElementById('navLinks');
        
        mobileMenuBtn.addEventListener('click', function() {
            navLinks.classList.toggle('active');
            mobileMenuBtn.innerHTML = navLinks.classList.contains('active') 
                ? '<i class="fas fa-times"></i>' 
                : '<i class="fas fa-bars"></i>';
        });

        // Close mobile menu when clicking outside
        document.addEventListener('click', function(event) {
            if (!mobileMenuBtn.contains(event.target) && !navLinks.contains(event.target)) {
                navLinks.classList.remove('active');
                mobileMenuBtn.innerHTML = '<i class="fas fa-bars"></i>';
            }
        });

        // Navbar scroll effect
        window.addEventListener('scroll', function() {
            const navbar = document.querySelector('.navbar');
            if (window.scrollY > 50) {
                navbar.style.backgroundColor = 'rgba(17, 17, 17, 0.95)';
                navbar.style.backdropFilter = 'blur(10px)';
            } else {
                navbar.style.backgroundColor = '#111111';
                navbar.style.backdropFilter = 'blur(10px)';
            }
        });

        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                const targetId = this.getAttribute('href');
                if (targetId === '#') return;
                
                const targetElement = document.querySelector(targetId);
                if (targetElement) {
                    // Close mobile menu if open
                    navLinks.classList.remove('active');
                    mobileMenuBtn.innerHTML = '<i class="fas fa-bars"></i>';
                    
                    // Smooth scroll
                    window.scrollTo({
                        top: targetElement.offsetTop - 80,
                        behavior: 'smooth'
                    });
                }
            });
        });

        // Create floating particles
        function createParticles() {
            const particlesContainer = document.getElementById('particles');
            const particleCount = 50;
            
            for (let i = 0; i < particleCount; i++) {
                const particle = document.createElement('div');
                particle.classList.add('particle');
                
                // Random position
                particle.style.left = `${Math.random() * 100}%`;
                particle.style.top = `${Math.random() * 100}%`;
                
                // Random size
                const size = Math.random() * 3 + 1;
                particle.style.width = `${size}px`;
                particle.style.height = `${size}px`;
                
                // Random opacity
                particle.style.opacity = Math.random() * 0.2 + 0.1;
                
                // Random animation
                particle.style.animationDelay = `${Math.random() * 15}s`;
                particle.style.animationDuration = `${Math.random() * 10 + 10}s`;
                
                particlesContainer.appendChild(particle);
            }
        }

        // Initialize particles
        createParticles();

        // Feature cards animation on scroll
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, { threshold: 0.1 });

        // Observe feature cards
        document.querySelectorAll('.feature-card').forEach(card => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(20px)';
            card.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
            observer.observe(card);
        });

        // Update active nav link based on scroll
        const sections = document.querySelectorAll('section');
        const navItems = document.querySelectorAll('.nav-link');
        
        window.addEventListener('scroll', function() {
            let current = '';
            sections.forEach(section => {
                const sectionTop = section.offsetTop;
                const sectionHeight = section.clientHeight;
                if (scrollY >= (sectionTop - 150)) {
                    current = section.getAttribute('id');
                }
            });

            navItems.forEach(item => {
                item.classList.remove('active');
                if (item.getAttribute('href') === `#${current}`) {
                    item.classList.add('active');
                }
            });
        });

        // Set active nav link for home
        window.addEventListener('load', function() {
            if (window.location.hash === '') {
                document.querySelector('a[href="index.php"]').classList.add('active');
            }
        });
    </script>
</body>
</html>